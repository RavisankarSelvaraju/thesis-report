#pragma once

#include <Eigen/Dense>
#include <vector>

namespace contact_velocity_odometry
{
    struct RobotState
    {
        EIGEN_MAKE_ALIGNED_OPERATOR_NEW

        Eigen::Matrix3d rotation;
        Eigen::Vector3d velocity;
        Eigen::Vector3d position;
        Eigen::Vector3d gyroscope_bias;
        Eigen::Vector3d accelerometer_bias;
    };

    struct NoiseParams
    {
        double noise_gyroscope;
        double noise_accelerometer;
    
        double noise_gyroscope_bias;
        double noise_accelerometer_bias;

        NoiseParams():
            noise_gyroscope(0.01),
            noise_accelerometer(0.1),
            noise_gyroscope_bias(0.00001),
            noise_accelerometer_bias(0.0001)
            {}
    };

    struct RobotConfiguration
    {
        // robot configuration parameters, such as hardware infomation can be stored here 
        size_t number_of_wheels;
        size_t number_of_contacts_per_wheel;
        
        std::string robot_urdf_path;

        RobotConfiguration():
            number_of_wheels(4),
            number_of_contacts_per_wheel(5),
            robot_urdf_path("")
            {}
    };
}
