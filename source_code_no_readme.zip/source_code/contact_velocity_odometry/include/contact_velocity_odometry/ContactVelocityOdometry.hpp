#ifndef _CONTACT_VELOCITY_ODOMETRY_ODOMETRY_HPP_
#define _CONTACT_VELOCITY_ODOMETRY_ODOMETRY_HPP_

#include <iostream>
#include <vector>
#include <string>
#include <kdl/frames.hpp>
#include <urdf_parser/urdf_parser.h>
#include <Eigen/Dense>
#include <inekf/InEKF.h>
#include "ContactVelocityOdometry_Types.hpp"

namespace contact_velocity_odometry
{
    class Odometry
    {
        private: 
            // create a pointer to the InEKF filter object, this will be used as public member variable 
            // so that we can set the state of filter from the orogen component
            std::unique_ptr<inekf::InEKF> filter; 
            bool estimate_bias = false; 
            contact_velocity_odometry::RobotConfiguration robot_config;

            /// @name Helper functions for odometry calculation
            /// @{
            /**
             * Computes the expected contact velocity in the body frame based on the current state estimate 
             * and the kinematics of the potential contact points. This is used for the contact velocity measurement update in the InEKF.
             * @param potential_contact_to_body_kinematics: <description>
             */

            void computeVectorKinematics(const std::vector<Eigen::Affine3d>& contact_frame_transforms,
                                        const std::vector<Eigen::Affine3d>& wheel_frame_fixed_transforms,
                                        const std::vector<Eigen::Affine3d>& feet_to_fixed_wheel_frames_transforms,
                                        inekf::vectorKinematics& potential_contact_to_body_kinematics,
                                        inekf::vectorKinematics& potential_contact_to_wheel_kinematics,
                                        inekf::vectorKinematics& wheel_to_body_kinematics); 
            void computeExpectedContactVelocity(
                                            const inekf::vectorKinematics& potential_contact_to_body_kinematics,
                                            const Eigen::Vector3d& omega_body_in_body,
                                            const Eigen::Matrix3d& R_world_to_body,
                                            const Eigen::Vector3d& v_body_in_world,
                                            Eigen::VectorXd& expected_contact_velocity_in_body);
                                        
            void computeMeasuredPotentialContactVelocity(
                                                    const std::vector<Eigen::Vector3d> wheel_velocities_vector,
                                                    const inekf::vectorKinematics& potential_contact_to_wheel_kinematics, 
                                                    const inekf::vectorKinematics& wheel_to_body_kinematics,
                                                    Eigen::VectorXd& measured_contact_velocity_in_body, 
                                                    Eigen::VectorXd& measured_contact_velocity_in_wheel,
                                                    const bool debug_mode);
            
            void GetGroundVelocityInWheelFrame(
                                    const Eigen::Matrix3d& R_wheel_to_world,
                                    const Eigen::Vector3d& p_wheel_in_world,
                                    const Eigen::Vector3d& v_wheel_in_world,
                                    const Eigen::Vector3d& omega_wheel_in_world,
                                    KDL::Twist& twist_ground_in_wheel);
            /// @}


            ///@name Eigen to KDL functions
            ///@{
            // 4x4 homogeneous transform
            inline KDL::Frame eigenToKDL(const Eigen::Matrix4d& T)
            {
                KDL::Rotation R(
                    T(0,0), T(0,1), T(0,2),
                    T(1,0), T(1,1), T(1,2),
                    T(2,0), T(2,1), T(2,2)
                );

                KDL::Vector p(T(0,3), T(1,3), T(2,3));
                return KDL::Frame(R, p);
            }   

            // Rotation + translation
            inline KDL::Frame eigenToKDL(const Eigen::Matrix3d& R_eig,
                                        const Eigen::Vector3d& p_eig)
            {
                KDL::Rotation R(
                    R_eig(0,0), R_eig(0,1), R_eig(0,2),
                    R_eig(1,0), R_eig(1,1), R_eig(1,2),
                    R_eig(2,0), R_eig(2,1), R_eig(2,2)
                );

                KDL::Vector p(p_eig.x(), p_eig.y(), p_eig.z());
                return KDL::Frame(R, p);
            }
            
            inline KDL::Twist eigenToKDL(const Eigen::Vector3d& v,
                                const Eigen::Vector3d& omega)
            {
                return KDL::Twist(
                    KDL::Vector(v.x(),     v.y(),     v.z()),
                    KDL::Vector(omega.x(), omega.y(), omega.z())
                );
            }
            /// @}

            /// @name Inekf <-> odom conversion functions
            /// @{
            
            inline void odom2inekfState(const RobotState& odom_state, inekf::RobotState& inekf_state) {
                inekf_state.setRotation(odom_state.rotation);
                inekf_state.setPosition(odom_state.position);
                inekf_state.setVelocity(odom_state.velocity);
                inekf_state.setGyroscopeBias(odom_state.gyroscope_bias);
                inekf_state.setAccelerometerBias(odom_state.accelerometer_bias);
            }

            inline void inekf2odomState(const inekf::RobotState& inekf_state, RobotState& odom_state) {
                odom_state.rotation = inekf_state.getRotation();
                odom_state.position = inekf_state.getPosition();
                odom_state.velocity = inekf_state.getVelocity();
                odom_state.gyroscope_bias = inekf_state.getGyroscopeBias();
                odom_state.accelerometer_bias = inekf_state.getAccelerometerBias();
            }

            inline void odom2inekfNoiseParams(const NoiseParams& odom_noise_params, inekf::NoiseParams& inekf_noise_params) {
                inekf_noise_params.setGyroscopeNoise(odom_noise_params.noise_gyroscope);
                inekf_noise_params.setAccelerometerNoise(odom_noise_params.noise_accelerometer);
                inekf_noise_params.setGyroscopeBiasNoise(odom_noise_params.noise_gyroscope_bias);
                inekf_noise_params.setAccelerometerBiasNoise(odom_noise_params.noise_accelerometer_bias);
            }

            /// @}
        public:

            /// @name Getters
            /// @{
                RobotState getState();
                void getNoiseParams(NoiseParams& noise_params);
                Eigen::MatrixXd getStateCovariance();
                Eigen::MatrixXd getKalmanGain();
                Eigen::MatrixXd getInnovations();
            /// @}

            /// @name Setters
            /// @{  
                void setState(const RobotState& state);
                void setEstimateBias(bool estimate_bias);
                void setNoiseParams(const NoiseParams& noise_params);
                void setRobotConfiguration(const RobotConfiguration& robot_configuration);
                void setGyroscopeBias(const Eigen::Vector3d& bg);
                void setAccelerometerBias(const Eigen::Vector3d& ba);
            /// @}



            void initialize(const RobotState& initial_state, 
                            const NoiseParams& noise_params);

            void initialize(const RobotState& initial_state);

            void propagate(const Eigen::Matrix<double,6,1>& measurement, const double dt);
            void correctContactVelocity(const std::vector<std::pair<std::string, float>>& wheel_names_speed_map,
                                        const std::vector<Eigen::Affine3d>& contact_frame_transforms,
                                        const std::vector<Eigen::Affine3d>& wheel_frame_fixed_transforms,
                                        const std::vector<Eigen::Affine3d>& feet_to_fixed_wheel_frames_transforms,
                                        const Eigen::Vector3d& omega_body_in_body,
                                        const double measurement_noise,
                                        const double chi_square_threshold,
                                        const double contact_md_threshold,
                                        const bool estimate_contacts,
                                        const bool enable_multi_contact_estimation,
                                        const bool pcv_gyro_bias_correction_enabled,
                                        const bool reject_slipping_spokes,
                                        odometry::BodyContactState& selected_contacts,     
                                        odometry::BodyContactState& md_selected_contacts,     
                                        std::vector<double>& mahalanobis_distances_for_all_wheels,
                                        std::vector<size_t>& slipping_spokes,
                                        const bool debug_mode);

    };

} // end namespace contact_velocity_odometry

#endif // _CONTACT_VELOCITY_ODOMETRY_ODOMETRY_HPP_
