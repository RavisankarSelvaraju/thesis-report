#include <boost/test/unit_test.hpp>
#include <contact_velocity_odometry/Dummy.hpp>

using namespace contact_velocity_odometry;

BOOST_AUTO_TEST_CASE(it_should_not_crash_when_welcome_is_called)
{
    contact_velocity_odometry::DummyClass dummy;
    dummy.welcome();
}
