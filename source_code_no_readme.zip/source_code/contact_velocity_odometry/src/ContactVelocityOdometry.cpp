#include "contact_velocity_odometry/ContactVelocityOdometry.hpp"
#include <iostream>

using namespace contact_velocity_odometry;

// Getters
RobotState Odometry::getState()
{   
    RobotState state;
    if (filter) {
        inekf::RobotState inekf_state = filter->getState();
        inekf2odomState(inekf_state, state);
    }
    else {
        std::cerr << "Filter is not initialized yet!" << std::endl;
        std::cerr << "Returning default state with zero rotation, position, velocity and biases." << std::endl;
    }
    return state;
} 

Eigen::MatrixXd Odometry::getKalmanGain()
{
    if (filter) {
        return filter->getKalmanGain();
    }
    else {
        std::cerr << "Filter is not initialized yet!" << std::endl;
        return Eigen::MatrixXd(); // Return empty matrix if filter is not initialized
    }
}

Eigen::MatrixXd Odometry::getInnovations()
{
    if (filter) {
        return filter->getInnovation();
    }
    else {
        std::cerr << "Filter is not initialized yet!" << std::endl;
        return Eigen::MatrixXd(); // Return empty matrix if filter is not initialized
    }
}

Eigen::MatrixXd Odometry::getStateCovariance()
{
    Eigen::MatrixXd P;
    if (filter) {
        auto state = filter->getState();
        P = state.getP();
    }
    else {
        std::cerr << "Filter is not initialized yet!" << std::endl;
        P = Eigen::MatrixXd::Zero(15, 15); // Return zero covariance if filter is not initialized
    }
    return P;
}
//Setters
void Odometry::initialize(  const contact_velocity_odometry::RobotState& initial_state, 
                            const contact_velocity_odometry::NoiseParams& noise_params)
{
    inekf::RobotState inekf_initial_state;
    inekf::NoiseParams inekf_noise_params;

    odom2inekfState(initial_state, inekf_initial_state);
    odom2inekfNoiseParams(noise_params, inekf_noise_params);
    
    Eigen::MatrixXd P0 = Eigen::MatrixXd::Zero(15, 15);

    // State order:
    // 0:3   rotation
    // 3:6   velocity
    // 6:9   position
    // 9:12  gyro bias
    // 12:15 accel bias

    P0.block<3,3>(0,0)   = std::pow(5.0 * M_PI / 180.0, 2) * Eigen::Matrix3d::Identity();
    P0.block<3,3>(3,3)   = std::pow(0.10, 2) * Eigen::Matrix3d::Identity();
    P0.block<3,3>(6,6)   = std::pow(0.0001, 2) * Eigen::Matrix3d::Identity();
    P0.block<3,3>(9,9)   = std::pow(0.02, 2) * Eigen::Matrix3d::Identity();
    P0.block<3,3>(12,12) = std::pow(0.20, 2) * Eigen::Matrix3d::Identity();

    inekf_initial_state.setP(P0);

    filter = std::unique_ptr<inekf::InEKF>(new inekf::InEKF(inekf_initial_state, inekf_noise_params));
}


void Odometry::setGyroscopeBias(const Eigen::Vector3d& bg)
{
    if (filter) {
        inekf::RobotState state = filter->getState();
        state.setGyroscopeBias(bg);
        filter->setState(state);
    }
    else {
        std::cerr << "Filter is not initialized yet!" << std::endl;
    }
}

void Odometry::setAccelerometerBias(const Eigen::Vector3d& ba)
{
    if (filter) {
        inekf::RobotState state = filter->getState();
        state.setAccelerometerBias(ba);
        filter->setState(state);
    }
    else {
        std::cerr << "Filter is not initialized yet!" << std::endl;
    }
}

void Odometry::initialize(const contact_velocity_odometry::RobotState& initial_state)
{
    // if NoiseParams is not provided, use default values
    contact_velocity_odometry::NoiseParams noise_params; // default constructor will set default noise values
    initialize(initial_state, noise_params);
}

void Odometry::setState(const contact_velocity_odometry::RobotState& state)
{   
    if (filter) {
        inekf::RobotState inekf_state;
        odom2inekfState(state, inekf_state);
        filter->setState(inekf_state);
    }
    else {
        std::cerr << "Filter is not initialized yet!" << std::endl;
    }
}

void Odometry::setEstimateBias(bool estimate_bias)
{
    if (filter) {
        this->estimate_bias = estimate_bias;
        
        // the estimate bias flag is used to enable or disable the gyro estimation from the update step. but if we use the same flag  to set the initial bias, it is erased
        // in every propagation step, so we need to set the estimate bias flag in the filter to true, so that the initial bias is not erased in every propagation step.
        // the this->estimate_bias flag is still used to enable or disable the gyro bias estimation from the update step. but when we set estimate_bias now, it by default sets the 
        // estimate bias flag in the filter to true, 
        filter->setEstimateBias(true);
    }
    else {
        std::cerr << "Filter is not initialized yet!" << std::endl;
    }
}

void Odometry::setRobotConfiguration(const contact_velocity_odometry::RobotConfiguration& config)
{
    robot_config = config;
}

void Odometry::setNoiseParams(const contact_velocity_odometry::NoiseParams& params)
{
    inekf::NoiseParams noise_params;
    odom2inekfNoiseParams(params, noise_params);
    filter->setNoiseParams(noise_params);
}

void Odometry::propagate(const Eigen::Matrix<double,6,1>& imu_measurement_vector, double dt)
{
    if (filter) {
        filter->Propagate(imu_measurement_vector, dt);
    }
    else {
        std::cerr << "Filter is not initialized yet!" << std::endl;
    }
}

void Odometry::computeExpectedContactVelocity(const inekf::vectorKinematics& potential_contact_to_body_kinematics,
                                            const Eigen::Vector3d& omega_body_in_body,
                                            const Eigen::Matrix3d& R_world_to_body,
                                            const Eigen::Vector3d& v_body_in_world,
                                            Eigen::VectorXd& expected_contact_velocity_in_body) 
{                                  
    /*
    Inputs:
    vectorKinematics potential_contact_to_body_kinematics: 
        Pose of each potential contact point wtr body frame in body frame
        
    Eigen::Vector3d omega_body_in_body: 
        Angular velocity of the IMU in body frame
        
    Eigen::Matrix3d R_world_to_body: 
        Rotates vectors from world frame to body frame
        
    Eigen::Vector3d v_body_in_world: 
        Linear velocity of the body in world frame
    
    Outputs:
    Eigen::VectorXd expected_contact_velocity_in_body: 
      A vector of expected contact point velocity vectors in body frame 
      
    Abbeviations:
    R: Rotation matrix
    p: Position vector
    v: Linear velocity vector
    omega: Angular velocity vector
    pc: Potential contact
    pcv: Potential contact velocity
    */
    
    // Each contact point will have a 3D velocity vector, so total size is 3 * number of contact points
    expected_contact_velocity_in_body.setZero(potential_contact_to_body_kinematics.size() * 3); 
    
    Eigen::Vector3d contact_velocity_in_body;
    
    // convert the v_body_in_world to body frame so linear and angular velocities are in the same frame
    const Eigen::Vector3d v_body_in_body = R_world_to_body * v_body_in_world;

    // Create twist of body in body frame
    const KDL::Twist twist_body_in_body = eigenToKDL(v_body_in_body, omega_body_in_body);
    
    // Measurement model calculation for body-centric contact velocity  
    // Expected Velocity: `contact_velocity_in_body = (R_world_to_body * v_body_in_world) + (omega_body_in_body × p_pc_in_body)`
    for (inekf::vectorKinematicsIterator it=potential_contact_to_body_kinematics.begin(); it!=potential_contact_to_body_kinematics.end(); ++it){
        
        // get the transformation from potential contact to body frame
        const KDL::Frame T_pc_to_body = eigenToKDL(it->pose);
        
        const KDL::Vector p_pc_in_body = T_pc_to_body.p;
        
        const KDL::Twist twist_at_pc = twist_body_in_body.RefPoint(p_pc_in_body);
            
        // Extract linear velocity component only from KDL::Twist
        contact_velocity_in_body << twist_at_pc.vel.x(), twist_at_pc.vel.y(), twist_at_pc.vel.z();
        
        // the contact velocity in body is calculating the absolute velocity of the a point attached to the body, 
        // it represents how fast the point is moving relative to the observer, 
        // but we want the velocity of world that is sliding under the contact point, 
        // so we should negate the contact velocity to get the velocity of contact point in body frame.?
        
        contact_velocity_in_body = - contact_velocity_in_body;

        // expected_contact_velocity is a single column vector with 3N elements, where N is the number of contact points)
        expected_contact_velocity_in_body.segment<3>(it->id * 3) = contact_velocity_in_body; 
    }
}

void Odometry::computeMeasuredPotentialContactVelocity(const std::vector<Eigen::Vector3d> wheel_velocities_vector,
                                                    const inekf::vectorKinematics& potential_contact_to_wheel_kinematics, 
                                                    const inekf::vectorKinematics& wheel_to_body_kinematics,
                                                    Eigen::VectorXd& measured_contact_velocity_in_body, 
                                                    Eigen::VectorXd& measured_contact_velocity_in_wheel,
                                                    const bool debug_mode)
{   
    /*
    Inputs:
    std::vector<Eigen::Vector3d> wheel_velocities_vector: 
        A vector of wheel rotational velocity vectors in rad/s
    
    vectorKinematics potential_contact_to_wheel_kinematics: 
        Pose of each potential contact point wtr corresponding fixed wheel frame(defined in URDF) in wheel frame
    
    vectorKinematics wheel_to_body_kinematics: 
        Pose of each wheel frame wtr body frame in body frame
        
    Outputs:
    Eigen::VectorXd measured_contact_velocity_in_body: 
      A vector of measured contact point velocity vectors in body frame
      
    Eigen::VectorXd measured_contact_velocity_in_wheel: 
      A vector of measured contact point velocity vectors in wheel frame (for debug)
    

    // Assumptions:
    // - The wheel velocities are given in rad/s
    // - The wheel velocities are in the order of FL, RL, RR, FR, i.e. front left, rear left, rear right, front right. in counter-clockwise order starting from front left
    // - The wheel velocities are vector of floats, where each element corresponds to a wheel s rotational velocity.
    // - The wheel velocities are around the y-axis of body frame, i.e. the wheel is rotating around the y-axis and the contact point is moving in the x-z plane of the body frame.
    // - In wheel frame, the wheel rotates around the z-axis.
    // - the Id in Kinematics is sequential, FL, RL, RR, FR, in this order, since each wheel has 5 contact points, the ids will start from 0 to 19.  
    */
        
    //Calcuate Number of wheels and spokes per wheel using the input data
    size_t total_num_spokes =  potential_contact_to_wheel_kinematics.size();
    size_t num_wheels = wheel_velocities_vector.size();
    size_t num_spokes_per_wheel = total_num_spokes / num_wheels;

    measured_contact_velocity_in_body.setZero(total_num_spokes * 3); 
    measured_contact_velocity_in_wheel.setZero(total_num_spokes * 3); // (for debug)

    // Iterate over each wheel [0,1,2,3] calculate the measured_contact_velocity
    for (size_t wheel_id = 0; wheel_id < num_wheels; ++wheel_id) {

        // Iterate over each spoke [0,1,2,3,4] and calculate the measured_contact_velocity
        for (size_t spoke_id = 0; spoke_id < num_spokes_per_wheel; ++spoke_id) {
            
            // Get position vector form pc to wheel center in wheel frame
            const Eigen::Matrix4d& T_potential_contact_to_wheel = potential_contact_to_wheel_kinematics[wheel_id * num_spokes_per_wheel + spoke_id].pose;
            Eigen::Vector3d p_pc_in_wheel = T_potential_contact_to_wheel.block<3,1>(0,3); 
            
            // Get wheel angular velocity vector in wheel frame (Wheel rotates around z-axis in wheel frame)
            Eigen::Vector3d omega_wheel_in_wheel = wheel_velocities_vector[wheel_id];
              
            // Calculate contact velocity in wheel frame (for debug)
            Eigen::Vector3d contact_velocity_in_wheel = omega_wheel_in_wheel.cross(p_pc_in_wheel); 

            // Get rotation matrix from wheel frame to body frame (Convert p_pc_in_wheel and omega_wheel to body_frame first before calculating cross product)
            const Eigen::Matrix4d& T_wheel_to_body = wheel_to_body_kinematics[wheel_id].pose;
            Eigen::Matrix3d R_wheel_to_body = T_wheel_to_body.block<3,3>(0,0); 
            
            // // Transform position vector and wheel angular velocity vector to body frame
            // Eigen::Vector3d p_pc_in_body = R_wheel_to_body * p_pc_in_wheel; 
            // Eigen::Vector3d omega_wheel_in_body = R_wheel_to_body * omega_wheel_in_wheel; 
            
            // // Calculate contact velocity in body frame
            // Eigen::Vector3d contact_velocity_in_body = omega_wheel_in_body.cross(p_pc_in_body);            
            
            // Alternative way: Transform contact velocity directly to body frame
            Eigen::Vector3d contact_velocity_in_body = R_wheel_to_body * contact_velocity_in_wheel;
            
            // (for debug) 
            measured_contact_velocity_in_wheel.segment<3>((wheel_id * num_spokes_per_wheel + spoke_id) * 3) = contact_velocity_in_wheel; 
            // Append the calculated contact velocities to the output vectors
            measured_contact_velocity_in_body.segment<3>((wheel_id * num_spokes_per_wheel + spoke_id) * 3) = contact_velocity_in_body;

        }
    }
}


void Odometry::computeVectorKinematics(const std::vector<Eigen::Affine3d>& contact_frame_transforms,
                                     const std::vector<Eigen::Affine3d>& wheel_frame_fixed_transforms,
                                     const std::vector<Eigen::Affine3d>& feet_to_fixed_wheel_frames_transforms,
                                     inekf::vectorKinematics& potential_contact_to_body_kinematics,
                                     inekf::vectorKinematics& potential_contact_to_wheel_kinematics,
                                     inekf::vectorKinematics& wheel_to_body_kinematics){

    // ------------------------Construct Kinematics for each contact and wheel frame ----------------
    
    potential_contact_to_wheel_kinematics.clear();
    potential_contact_to_body_kinematics.clear();
    wheel_to_body_kinematics.clear();

    for (size_t wheel_idx = 0; wheel_idx < robot_config.number_of_wheels; ++wheel_idx) {

        // Construct "wheel_to_body_kinematics"
        Eigen::Matrix<double,6,6> covariance_w2b  = 0.0001 * Eigen::Matrix<double,6,6>::Identity(); // or use a more appropriate covariance matrix
        inekf::Kinematics wheel2body_kinematics(wheel_idx, wheel_frame_fixed_transforms[wheel_idx].matrix(), covariance_w2b);
        wheel_to_body_kinematics.push_back(wheel2body_kinematics);
        
        for (size_t contact_idx = 0; contact_idx < robot_config.number_of_contacts_per_wheel; ++contact_idx) {
            int global_contact_idx = wheel_idx * robot_config.number_of_contacts_per_wheel + contact_idx;
            
            Eigen::Matrix4d potential_contact2wheel = feet_to_fixed_wheel_frames_transforms[global_contact_idx].matrix();
            Eigen::Matrix4d potential_contact2base  = contact_frame_transforms[global_contact_idx].matrix();
            
            // Construct "potential_contact_to_wheel_kinematics"
            Eigen::Matrix<double,6,6> covariance_pc2w = 0.0001 * Eigen::Matrix<double,6,6>::Identity(); // or use a more appropriate covariance matrix
            inekf::Kinematics potential_contact2wheel_kinematics(global_contact_idx, potential_contact2wheel, covariance_pc2w);
            potential_contact_to_wheel_kinematics.push_back(potential_contact2wheel_kinematics);
            
            // Construct "potential_contact_to_body_kinematics"
            Eigen::Matrix<double,6,6> covariance_pc2b = 0.0001 * Eigen::Matrix<double,6,6>::Identity(); // or use a more appropriate covariance matrix
            inekf::Kinematics potential_contact2body_kinematics(global_contact_idx, potential_contact2base, covariance_pc2b);
            potential_contact_to_body_kinematics.push_back(potential_contact2body_kinematics);
        }
    }
}
    
void Odometry::correctContactVelocity(const std::vector<std::pair<std::string, float>>& wheel_names_speed_map,
                                        const std::vector<Eigen::Affine3d>& contact_frame_transforms,
                                        const std::vector<Eigen::Affine3d>& wheel_frame_fixed_transforms,
                                        const std::vector<Eigen::Affine3d>& feet_to_fixed_wheel_frames_transforms,
                                        const Eigen::Vector3d& omega_body_in_body,
                                        const double measurement_noise,
                                        const double chi_square_threshold,
                                        const double contact_md2_threshold,
                                        const bool estimate_contacts,
                                        const bool enable_multi_contact_estimation,
                                        const bool pcv_gyro_bias_correction_enabled,
                                        const bool reject_slipping_spokes,
                                        odometry::BodyContactState& lf_selected_contacts,     
                                        odometry::BodyContactState& md_selected_contacts,
                                        std::vector<double>& mahalanobis_distances_for_all_wheels,
                                        std::vector<size_t>& slipping_spokes,
                                        const bool debug_mode) 
{

    /*
    Inputs:
    
    std::vector<std::pair<std::string, float>> wheel_names_speed_map: 
        A vector of pairs of wheel names and their rotational velocities in rad/s
        
    vectorKinematics potential_contact_to_body_kinematics: 
        Pose of each potential contact point wtr body frame in body frame
        
    vectorKinematics potential_contact_to_wheel_kinematics: 
        Pose of each potential contact point wtr corresponding wheel frame in wheel frame
        
    vectorKinematics wheel_to_body_kinematics: 
        Pose of each wheel frame wtr body frame in body frame
        
    Eigen::Vector3d omega_body_in_body: 
        Angular velocity of the IMU in body frame
        
    bool debug_mode: 
        If true, print debug information, this information is currently used for plotting and analysis.
    */
    
    // Assumptions:
    // - multiple spokes can be in contact, ie, more than one contact can be possible
    
    // -----------------------------------------------------------------------------------------------------------------------------
    
    // Input validity checks
    if (wheel_names_speed_map.size() == 0) {
        std::cerr << "Error: wheel_names_speed_map is empty!" << std::endl;
        return;
    }
    if (contact_frame_transforms.size() == 0) {
        std::cerr << "Error: contact_frame_transforms vector is empty!" << std::endl;
        return;
    }
    if (feet_to_fixed_wheel_frames_transforms.size() == 0) {
        std::cerr << "Error: feet_to_fixed_wheel_frames_transforms vector is empty!" << std::endl;
        return;
    }
    if (wheel_frame_fixed_transforms.size() == 0) {
        std::cerr << "Error: wheel_frame_fixed_transforms vector is empty!" << std::endl;
        return;
    }
    if (omega_body_in_body.size() != 3) {
        std::cerr << "Error: omega_body_in_body vector size is not 3!" << std::endl;
        return;
    }

    // get the current state of the filter 
    if (!filter) {
        std::cerr << "Filter is not initialized yet!" << std::endl;
        return;
    }
    
    auto state_ = filter->getState();

    // get the setEstimateBias flag
    if (debug_mode) {
        std::cout << "setEstimateBias is set to ->" << filter->getEstimateBias() << std::endl;
    }

    // ----------------------------------------------------------------------------------------------------------------------------
    // Load robot URDF and parse rotation axis information
    std::vector<Eigen::Vector3d> wheel_velocities; 
    urdf::ModelInterfaceSharedPtr model;

    // 1. parse URDF using urdfdom
    try{
        model = urdf::parseURDFFile(robot_config.robot_urdf_path);
    }
    catch (const std::exception& e) {
        std::cerr << "Error: Failed to parse URDF file! " << e.what() << std::endl;
        return;
    }

    for (const auto& wheel_pair : wheel_names_speed_map)
    {
        const std::string& wheel_name = wheel_pair.first;
        const float& wheel_speed = wheel_pair.second;

        // 2. Get the joint corresponding to the wheel name
        auto joint = model->getJoint(wheel_name);
        if (!joint) {
            std::cerr << "Error: Joint with name " << wheel_name << " not found in URDF!" << std::endl;
            return;
        }
        // 3. Extract the rotation axis of the wheel from the URDF joint information
        Eigen::Vector3d wheel_velocity_vec = wheel_speed * Eigen::Vector3d(joint->axis.x, joint->axis.y, joint->axis.z);

        wheel_velocities.push_back(wheel_velocity_vec);
    }    

    // If true  -> slipping spokes are rejected from the EKF update.
    // If false -> slipping spokes are still included in the EKF update.
    // The slip/debug vectors are still computed in both cases.
    const bool reject_slipping_spokes_from_update = reject_slipping_spokes;

    // -----------------------------------------------------------------------------------------------------------------------------
      
    std::vector<Eigen::Vector3d> accepted_innovations;
    std::vector<Eigen::MatrixXd> accepted_jacobians;
    std::vector<Eigen::Matrix3d> accepted_noises;

    inekf::vectorKinematics potential_contact_to_body_kinematics;
    inekf::vectorKinematics potential_contact_to_wheel_kinematics;
    inekf::vectorKinematics wheel_to_body_kinematics;

    computeVectorKinematics(contact_frame_transforms, wheel_frame_fixed_transforms, feet_to_fixed_wheel_frames_transforms, 
                            potential_contact_to_body_kinematics, potential_contact_to_wheel_kinematics, wheel_to_body_kinematics);
    
    // Calculate Number of wheels and spokes per wheel using the input data
    size_t num_wheels = robot_config.number_of_wheels;
    size_t num_spokes_per_wheel = robot_config.number_of_contacts_per_wheel;
    size_t total_num_spokes = num_wheels * num_spokes_per_wheel;
    //  -----------------------------------------------------------------------------------------------------------------------------
    // Compute expected and measured contact velocities

    // Initialize expected and measured contact velocity vectors
    Eigen::VectorXd expected_contact_velocity_in_body, measured_contact_velocity_in_body, measured_contact_velocity_in_wheel; 
    
    // Get R_world_to_body and v_body_in_world from current state estimate
    const Eigen::Matrix3d R_body_to_world = state_.getRotation();
    const Eigen::Matrix3d R_world_to_body = R_body_to_world.transpose();
    // Use getWorldVelocity() to ensure the velocity is expressed in the WORLD frame
    const Eigen::Vector3d v_body_in_world = state_.getWorldVelocity();
    
    Eigen::Vector3d omega_corrected = omega_body_in_body - state_.getGyroscopeBias();
    // Compute Expected contact velocity based on current state estimate
    computeExpectedContactVelocity(potential_contact_to_body_kinematics, omega_corrected, R_world_to_body, v_body_in_world, expected_contact_velocity_in_body);

    // Compute Measured contact velocity based on wheel velocities
    computeMeasuredPotentialContactVelocity(wheel_velocities, potential_contact_to_wheel_kinematics, wheel_to_body_kinematics, measured_contact_velocity_in_body, measured_contact_velocity_in_wheel, debug_mode); 

    // -----------------------------------------------------------------------------------------------------------------------------
    // check the size of expected_contact_velocity_in_body and measured_contact_velocity_in_body
    
    if ((expected_contact_velocity_in_body.size() != measured_contact_velocity_in_body.size()) || (measured_contact_velocity_in_body.size() != total_num_spokes * 3)) {
        std::cerr << "Error: expected_contact_velocity_in_body and measured_contact_velocity_in_body must be the same size and should be " << total_num_spokes * 3 << "!" << std::endl;
        return;
    }
    
    // ----------------------------------------------------------------------------------------------------------------------------
    // convert the expected_contact_velocity_in_body to wheel frame to compare with measured_contact_velocity_in_wheel (for debug and visualization)
    
    Eigen::VectorXd expected_contact_velocity_in_wheel;
    expected_contact_velocity_in_wheel.setZero(total_num_spokes * 3);

    // iterate over each spoke and convert the expected_contact_velocity_in_wheel to wheel frame
    for (size_t wheel_id = 0; wheel_id < num_wheels; ++wheel_id) {        
        
        const Eigen::Matrix3d R_wheel_to_body = wheel_to_body_kinematics[wheel_id].pose.block<3,3>(0,0); 
        const Eigen::Matrix3d R_body_to_wheel = R_wheel_to_body.transpose(); 
        for (size_t spoke_id = 0; spoke_id < num_spokes_per_wheel; ++spoke_id) {
            
            size_t global_spoke_idx = wheel_id * num_spokes_per_wheel + spoke_id;
            const Eigen::Vector3d expected_velocity_in_body = expected_contact_velocity_in_body .segment<3>(global_spoke_idx * 3);
            
            // Rotate spoke velocity from body frame to wheel frame
            Eigen::Vector3d expected_velocity_in_wheel = R_body_to_wheel * expected_velocity_in_body;
            
            expected_contact_velocity_in_wheel.segment<3>(global_spoke_idx * 3) = expected_velocity_in_wheel;
        }
    }
    
    // ---------------------------------------------------------------------------------------------------------------------------
    // Compute residuals, jacobians and noise all points only and aggregate them
    
    // store spokes with contacts as global_spoke_id E [0, total_num_spokes]
    std::vector<size_t> spokes_in_contact; 
    std::vector<size_t> md_spokes_in_contact;
    std::vector<size_t> lf_spokes_in_contact;
    
    // out of contacts non slippling contacts
    std::vector<size_t> selected_spokes_for_update;
    std::vector<double> mahalanobis_distances_for_wheel;
    mahalanobis_distances_for_all_wheels.clear();
    mahalanobis_distances_for_all_wheels.reserve(num_wheels * num_spokes_per_wheel);
    mahalanobis_distances_for_wheel.reserve(num_spokes_per_wheel);
    
    struct SpokeData {
        double in_contact = -99; // 1 if in contact, 0 if not in contact, -99 if not determined yet
        double non_slipping = -99; // 1 if non-slipping, 0 if slipping, -99 if not determined yet
        Eigen::Vector3d innovation;
        Eigen::MatrixXd jacobian;
        Eigen::Matrix3d noise;
    };
    
    std::map<size_t, SpokeData> spoke_data_map; // key is global_spoke_id, value is SpokeData struct
    slipping_spokes.clear();
    for (size_t wheel_id = 0; wheel_id < num_wheels; ++wheel_id){  
        const Eigen::Matrix3d R_wheel_to_body = wheel_to_body_kinematics[wheel_id].pose.block<3,3>(0,0);
        mahalanobis_distances_for_wheel.clear();     
        for (size_t spoke_id = 0; spoke_id < num_spokes_per_wheel; ++spoke_id) {
            
            size_t global_spoke_idx = wheel_id * num_spokes_per_wheel + spoke_id;

            // Get measured, expected and ground truth contact velocities for the current spoke
            Eigen::VectorXd measured_velocity_in_body = measured_contact_velocity_in_body.segment<3>(global_spoke_idx * 3); 
            Eigen::VectorXd measured_velocity_in_wheel = measured_contact_velocity_in_wheel.segment<3>(global_spoke_idx * 3);
            
            Eigen::VectorXd expected_velocity_in_body = expected_contact_velocity_in_body.segment<3>(global_spoke_idx * 3);
            Eigen::VectorXd expected_velocity_in_wheel = expected_contact_velocity_in_wheel.segment<3>(global_spoke_idx * 3);
                
            // INNOVATION aka residual measured_velocity_in_body
            Eigen::Vector3d innovation = measured_velocity_in_body - expected_velocity_in_body;

            // OBSERVATION MATRIX (Jacobian) for Body-Centric Left-Invariant InEKF
            Eigen::MatrixXd observation_matrix(3, state_.dimP());
            observation_matrix.setZero();

            // 1. Rotation Block (0,0): .
            // observation_matrix.block<3,3>(0,0) =  -(inekf::skew(R_world_to_body * v_body_in_world));
            
            Eigen::Vector3d v_body = R_world_to_body * v_body_in_world; // velocity of body in body frame, used for jacobian calculation
            observation_matrix.block<3,3>(0,0) =  -(inekf::skew(v_body));
            
            // 2. Velocity Block (0,3): The derivative of (-v_body) w.r.t the velocity error.
            observation_matrix.block<3,3>(0,3) = -Eigen::Matrix3d::Identity();
            
            // 3. Gyro Bias Block (0,9): Since PCV depends on omega, you MUST account for bg.
            // Derivative of [-( (omega - bg) x r )] w.r.t bg is -skew(r).
            // This allows the PCV update to actually tune/fix your gyro bias!
            
            if (pcv_gyro_bias_correction_enabled)
            {
                Eigen::Vector3d r_pc =  potential_contact_to_body_kinematics[global_spoke_idx].pose.block<3,1>(0,3);
                observation_matrix.block<3,3>(0,9) = -(inekf::skew(r_pc));
            }
            else
            {
                observation_matrix.block<3,3>(0,9) = Eigen::Matrix3d::Zero();
            }

            // MEASUREMENT COVARIANCE MATRIX spoke_N
            double contact_velocity_measurement_std = measurement_noise;
            Eigen::Matrix3d measurement_noise_matrix = Eigen::Matrix3d::Identity() * contact_velocity_measurement_std * contact_velocity_measurement_std;  
            
            // increase the measurement noise in the y axis of the body frame
            measurement_noise_matrix(1,1) *= 100.0; 
            // Temporarily reduce vertical trust in PCV update
            // measurement_noise_matrix(2,2) *= 100.0;   // or 1000.0
            
            // --------------------------------- CALCULATE MAHALANOBIS DISTANCE -------------------------------------------
            
            // 1. Innovation Covariance S = H * P * H^T + N
            Eigen::Matrix3d innovation_covariance_matrix = observation_matrix * state_.getP() * observation_matrix.transpose() + measurement_noise_matrix;
                   
            // 2. Mahalanobis distance d^2 = innovation^T * S^-1 * innovation
            double mahalanobis_distance_squared = innovation.transpose() * innovation_covariance_matrix.inverse() * innovation;
            mahalanobis_distances_for_wheel.push_back(mahalanobis_distance_squared);
            
            // --------------------------------- UPDATE THE SPOKE_DATA STRUCTURE --------------------------------------------
            spoke_data_map[global_spoke_idx].innovation = innovation;
            spoke_data_map[global_spoke_idx].jacobian = observation_matrix;
            spoke_data_map[global_spoke_idx].noise = measurement_noise_matrix;
            
            // if the mahalanobis distance is less than the chi-square threshold, we consider the spoke to be not slipping
            if (mahalanobis_distance_squared < chi_square_threshold){
                spoke_data_map[global_spoke_idx].non_slipping = 1.0;  
            }

            else {
                spoke_data_map[global_spoke_idx].non_slipping = 0.0;
            }
        
            // -------------------------------------------------------------------------------------------------------------
            // Debug information printout
            if (debug_mode) {
                Eigen::IOFormat CleanFormat(4, 0, ", ", "\n", "[", "]");
                std::cout << " <<<< ============== ============== ============== >>>> " << std::endl;
                std::cout << "[DEBUG] Processing spoke point ID: " << global_spoke_idx << std::endl;
                
                std::cout << "[DEBUG] state_velocity_body_in_world ->" << v_body_in_world.transpose().format(CleanFormat) << "\n";    
                
                std::cout << "[DEBUG] state_expected_velocity_in_body ->" << expected_velocity_in_body.transpose().format(CleanFormat) << "\n";
                std::cout << "[DEBUG] state_expected_velocity_in_wheel ->" << expected_velocity_in_wheel.transpose().format(CleanFormat) << "\n";

                std::cout << "[DEBUG] measured_velocity_in_body ->" << measured_velocity_in_body.transpose().format(CleanFormat) << "\n";
                std::cout << "[DEBUG] measured_velocity_in_wheel ->" << measured_velocity_in_wheel.transpose().format(CleanFormat) << "\n";
                
                std::cout << "[DEBUG] innovation (residual) ->" << innovation.transpose().format(CleanFormat) << "\n";
                
                std::cout << "[DEBUG] position_potential_contact_to_body_kinematics ->" << potential_contact_to_body_kinematics[global_spoke_idx].pose.block<3,1>(0,3).transpose().format(CleanFormat) << "\n";
                std::cout << "[DEBUG] position_potential_contact_to_wheel_kinematics ->" << potential_contact_to_wheel_kinematics[global_spoke_idx].pose.block<3,1>(0,3).transpose().format(CleanFormat) << "\n";
                std::cout << "[DEBUG] position_wheel_to_body_kinematics ->" << wheel_to_body_kinematics[wheel_id].pose.block<3,1>(0,3).transpose().format(CleanFormat) << "\n";
                
                std::cout << "[DEBUG] R_wheel_to_body ->["
                          << R_wheel_to_body(0,0) << ", " << R_wheel_to_body(0,1) << ", " << R_wheel_to_body(0,2) << ", "
                          << R_wheel_to_body(1,0) << ", " << R_wheel_to_body(1,1) << ", " << R_wheel_to_body(1,2) << ", "
                          << R_wheel_to_body(2,0) << ", " << R_wheel_to_body(2,1) << ", " << R_wheel_to_body(2,2)
                          << "]\n";
                
                std::cout << " <<<< ============== ============== ============== >>>> " << std::endl;

            }
            
        }
        
        //for each wheel we check which spoke has lowest mahalanobis distance and use that as the contact point for that wheel.
            
        // TODO: This wont work, when the robot is stationary because all the distance values will be same since, the wheel velocity is zero.
        // ========================================================== //
        // select the spoke that has the lowest mahalanobis distance  //
        // ========================================================== //
        
        if (mahalanobis_distances_for_wheel.size() != num_spokes_per_wheel) {
            std::cerr << "Error: mahalanobis_distances_for_wheel size is not equal to num_spokes_per_wheel!" << std::endl;
            return;
        }
        
        for (const auto& dist : mahalanobis_distances_for_wheel) {
            mahalanobis_distances_for_all_wheels.push_back(dist);
        }

        // Initialize first two distances
        double dist_min_1 = mahalanobis_distances_for_wheel[0];
        double dist_min_2 = mahalanobis_distances_for_wheel[1];

        size_t spoke_in_contact_local_id_1 = 0;
        size_t spoke_in_contact_local_id_2 = 1;

        // Ensure correct ordering (dist_min_1 <= dist_min_2)
        if (dist_min_2 < dist_min_1) {
            std::swap(dist_min_1, dist_min_2);
            std::swap(spoke_in_contact_local_id_1, spoke_in_contact_local_id_2);
        }

        // Iterate through remaining spokes
        for (size_t spoke_id = 2; spoke_id < num_spokes_per_wheel; ++spoke_id) {
            
            double current_dist = mahalanobis_distances_for_wheel[spoke_id];
            if (current_dist < dist_min_1) {
                // New smallest
                dist_min_2 = dist_min_1;
                spoke_in_contact_local_id_2 = spoke_in_contact_local_id_1;

                dist_min_1 = current_dist;
                spoke_in_contact_local_id_1 = spoke_id;
            }
            else if (current_dist < dist_min_2) {
                // New second smallest
                dist_min_2 = current_dist;
                spoke_in_contact_local_id_2 = spoke_id;
            }
        }
        
        // calculate the difference between the two minimum distances of MD(mahalanobis distance)
        // if the difference is less than a threshold, we consider both points as in contact, 
        // otherwise we only consider the point with minimum distance as in contact
        
        double diff_md2_distance = dist_min_2 - dist_min_1;
        // std::cout << "[DEBUG] Wheel " << wheel_id  << std::endl;
        // std::cout << "[DEBUG] Least distance: " << dist_min_1 << ", Next Least distance: " << dist_min_2 << std::endl;
        // std::cout << "[DEBUG] difference: " << diff_md2_distance << std::endl;
        // both spokes are in contact 
        size_t global_spoke_idx_min_1 = wheel_id * num_spokes_per_wheel + spoke_in_contact_local_id_1;
        size_t global_spoke_idx_min_2 = wheel_id * num_spokes_per_wheel + spoke_in_contact_local_id_2;
            
        if (enable_multi_contact_estimation &&
            diff_md2_distance < contact_md2_threshold) 
        {
            md_spokes_in_contact.push_back(global_spoke_idx_min_1);
            md_spokes_in_contact.push_back(global_spoke_idx_min_2);
        }
        else 
        {
            md_spokes_in_contact.push_back(global_spoke_idx_min_1);
        }
        // std::cout << "[DEBUG] Least distance ids " << global_spoke_idx_min_1 << ", " << global_spoke_idx_min_2 << std::endl;
        
        // ============================================================================= //
        // Select one contact point per wheel based on the lowest Z value in body frame  //
        // ============================================================================= //
        
        size_t first_spoke_id = wheel_id * num_spokes_per_wheel;
        
        // The Z value in body frame is taken not the wheel frame
        double lowest_z_position = potential_contact_to_body_kinematics[first_spoke_id].pose(2,3); 
        size_t lowest_spoke_id = first_spoke_id;
        
        // use global spoke id to iterate potential_contact_to_body_kinematics since, it contains pose of all the spokes in body frame
        for (size_t spoke_id = 1; spoke_id < num_spokes_per_wheel; ++spoke_id) {
            
            size_t current_spoke_id = wheel_id * num_spokes_per_wheel + spoke_id;
            
            if (potential_contact_to_body_kinematics[current_spoke_id].pose(2,3) < lowest_z_position) {
                lowest_z_position = potential_contact_to_body_kinematics[current_spoke_id].pose(2,3);
                lowest_spoke_id = current_spoke_id;
            }
        }
        if (!enable_multi_contact_estimation)
        {
            // Single LF contact: only the lowest spoke
            lf_spokes_in_contact.push_back(lowest_spoke_id);
        }
        else
        {
            // Multi LF contact: all spokes close to the lowest z
            double delta = 0.02;  // meters
            double z_threshold = lowest_z_position + delta;

            for (size_t spoke_id = 0; spoke_id < num_spokes_per_wheel; ++spoke_id)
            {
                size_t global_id = wheel_id * num_spokes_per_wheel + spoke_id;

                double z = potential_contact_to_body_kinematics[global_id].pose(2,3);

                if (z <= z_threshold)
                {
                    lf_spokes_in_contact.push_back(global_id);
                }
            }
        }
    }
    // std::cout << "===================================================================" << std::endl;
    
    
    // if wheel speed is zero then use lowest Z position method to estimate contact, when the wheel starts moving we can switch to mahalanobis distance method
    
    // // Check if the robot is stationary based on wheel speeds and body angular velocity
    // double mean_abs_wheel_speed = 0.0;
    // for (const auto& wheel_pair : wheel_names_speed_map) {
    //     mean_abs_wheel_speed += std::abs(wheel_pair.second);
    // }
    // mean_abs_wheel_speed /= wheel_names_speed_map.size();
    
    // bool currently_stationary = mean_abs_wheel_speed < 0.03 &&  omega_body_in_body.norm() < 0.03;  
    
    // if (currently_stationary) {
    // if (mean_abs_wheel_speed > 0.06 || omega_body_in_body.norm() > 0.06)
    //     currently_stationary = false;
    // } else {
    //     if (mean_abs_wheel_speed < 0.02 && omega_body_in_body.norm() < 0.02)
    //         currently_stationary = true;
    // }
    
    if (!estimate_contacts) {
        if (debug_mode) { std::cout << "[DEBUG] Using lowest Z position based contact estimation." << std::endl; }
        spokes_in_contact = lf_spokes_in_contact;
    }
    else {
        if (debug_mode) { std::cout << "[DEBUG] Using Mahalanobis distance based contact estimation." << std::endl; }
        spokes_in_contact = md_spokes_in_contact;
    }
    
    
    // after processing all spokes of all the wheels 
    // print selected indices (for debug)
    if (spokes_in_contact.size() > total_num_spokes) {
        std::cerr << "Error: Number of spokes in contact cannot be greater than total number of spokes!" << std::endl;
        return;
    }

    if (debug_mode){
        std::cout << "[DEBUG] Number of selected contact points: " << spokes_in_contact.size() << std::endl;
        for (size_t idx : spokes_in_contact) {
        std::cout << "[DEBUG] Selected contact points index: " << idx << std::endl;
        }
    }
    
    // update the spoke_data_map with contact information 
    for (auto& [idx, data] : spoke_data_map) {

        if (std::find(spokes_in_contact.begin(), spokes_in_contact.end(), idx) != spokes_in_contact.end()) {
            data.in_contact = 1.0;
        } 
        else {
            data.in_contact = 0.0;
        }

        const bool spoke_is_in_contact = (data.in_contact == 1.0);
        const bool spoke_is_non_slipping = (data.non_slipping == 1.0);
        const bool spoke_is_slipping = (data.non_slipping == 0.0);

        // Always update slipping_spokes for debug/logging
        if (spoke_is_in_contact && spoke_is_slipping) {
            slipping_spokes.push_back(idx);
        }

        bool use_spoke_for_update = false;

        if (spoke_is_in_contact) {

            if (reject_slipping_spokes_from_update) {
                // Slip rejection ON:
                // only non-slipping contact spokes are used
                if (spoke_is_non_slipping) {
                    use_spoke_for_update = true;
                }
            }
            else {
                // Slip rejection OFF:
                // all contact spokes are used, including slipping ones
                use_spoke_for_update = true;
            }
        }

        if (use_spoke_for_update) {
            selected_spokes_for_update.push_back(idx);
            accepted_innovations.push_back(data.innovation);
            accepted_jacobians.push_back(data.jacobian);
            accepted_noises.push_back(data.noise);
        }
    }
        
    // for debug purposes, we add a lf_selected_contacts, to be removed later    
    lf_selected_contacts.points.clear();
    for (size_t idx : lf_spokes_in_contact) {
        odometry::BodyContactPoint point;
        point.position = potential_contact_to_body_kinematics[idx].pose.block<3,1>(0,3);
        point.contact = 1.0;
        point.groupId = idx;
        lf_selected_contacts.points.push_back(point);
    }
    
    // for debug purposes, we add a md_selected_contacts, to be removed later
    md_selected_contacts.points.clear();
    for (size_t idx : md_spokes_in_contact) {
        odometry::BodyContactPoint point;
        
        point.position = potential_contact_to_body_kinematics[idx].pose.block<3,1>(0,3);
        point.contact = 1.0;
        point.groupId = idx;
        md_selected_contacts.points.push_back(point);
    }
    
    size_t num_selected_spokes_for_update = selected_spokes_for_update.size();
    if (num_selected_spokes_for_update == 0) {
        if (reject_slipping_spokes_from_update) {
            std::cout << "[DEBUG] No non-slipping contacts identified! Skipping correction update." << std::endl;
        }
        else {
            std::cout << "[DEBUG] No contact spokes identified! Skipping correction update." << std::endl;
        }    
    }
    else
    {
        if (debug_mode) { std::cout << "[DEBUG] Number of non-slipping contacts identified: " << num_selected_spokes_for_update << std::endl; }
    
        // Initialize aggregated residual, jacobian and noise matrices for all accepted spokes
        Eigen::VectorXd aggregated_contact_velocity_residual; 
        Eigen::MatrixXd aggregated_contact_velocity_jacobian; 
        Eigen::MatrixXd aggregated_contact_velocity_noise; 

        // Set the size of the aggregated matrices
        aggregated_contact_velocity_residual.setZero(num_selected_spokes_for_update * 3);
        aggregated_contact_velocity_jacobian.setZero(num_selected_spokes_for_update * 3, state_.dimP());
        aggregated_contact_velocity_noise.setZero(num_selected_spokes_for_update * 3, num_selected_spokes_for_update * 3);
        
        for (size_t i = 0; i < num_selected_spokes_for_update; ++i) {
            int row = i * 3;
            aggregated_contact_velocity_residual.segment<3>(row) = accepted_innovations[i];
            aggregated_contact_velocity_jacobian.block(row, 0, 3, state_.dimP()) = accepted_jacobians[i];
            aggregated_contact_velocity_noise.block(row, row, 3, 3) = accepted_noises[i]; 
        }
        
        if (debug_mode) { std::cout << "[DEBUG] Performing correction with " << num_selected_spokes_for_update << " accepted measurements." << std::endl; }
          
        filter->CorrectContactVelocity( aggregated_contact_velocity_residual, 
                                        aggregated_contact_velocity_jacobian, 
                                        aggregated_contact_velocity_noise); // Assuming Left Invariant Error Type
    }
}