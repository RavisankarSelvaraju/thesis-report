/* Generated from orogen/lib/orogen/templates/tasks/Task.cpp */

#include "Task.hpp"

using namespace contact_velocity_odometry_estimator;

Task::Task(std::string const& name)
    : TaskBase(name)
{
}

Task::~Task()
{
}

/// The following lines are template definitions for the various state machine
// hooks defined by Orocos::RTT. See Task.hpp for more detailed
// documentation about them.

bool Task::configureHook()
{
    if (! TaskBase::configureHook())
        return false;

    debug = _enable_debug.get();
    Eigen::Affine3d initial_pose = _initial_pose.get().toTransform();

    // if the initial pose is not set, use the first input pose as initial state
    if (initial_pose.matrix().isZero()) {
        p0 << 0,0,0.87;  // initial position
        R0 << 1, 0, 0,   // initial orientation
            0, 1, 0, 
            0, 0, 1;
    }
    else{
        p0 = initial_pose.translation();
        R0 = initial_pose.linear();
    }

    v0 << 0,0,0;     // initial velocity
    bg0 << 0,0,0;    // initial gyroscope bias
    ba0 << 0,0,0;    // initial accelerometer bias

    // Initialize filter state
    initial_state.rotation = R0;
    initial_state.velocity = v0;
    initial_state.position = p0;
    initial_state.gyroscope_bias = bg0;
    initial_state.accelerometer_bias = ba0;

    // Initialize noise values from the properties
    noise_params.noise_gyroscope = _noise_parameters.get().noise_gyroscope;
    noise_params.noise_accelerometer = _noise_parameters.get().noise_accelerometer;
    noise_params.noise_gyroscope_bias = _noise_parameters.get().noise_gyroscope_bias;
    noise_params.noise_accelerometer_bias = _noise_parameters.get().noise_accelerometer_bias;

    measurement_noise = _measurement_noise.get();
    chi_squared_threshold = _chi_squared_threshold.get();
    estimate_contacts = _estimate_contacts.get();
    enable_multi_contact_estimation = _enable_multi_contact_estimation.get();
    contact_md2_threshold = _contact_md2_threshold.get();
    reject_slipping_spokes = _reject_slipping_spokes.get();
    
    set_initial_acc_bias_estimate = _set_initial_acc_bias_estimate.get();
    set_initial_gyro_bias_estimate = _set_initial_gyro_bias_estimate.get();
    
    pcv_gyro_bias_correction_enabled = _enable_pcv_gyro_bias_correction.get();

    contact_velocity_odometry::RobotConfiguration robot_configuration;  

    // Initialize robot configuration from the properties
    robot_configuration.number_of_wheels = _robot_configuration.get().number_of_wheels;
    robot_configuration.number_of_contacts_per_wheel = _robot_configuration.get().number_of_contacts_per_wheel;
    robot_configuration.robot_urdf_path = _robot_configuration.get().robot_urdf_path;

    num_wheels = robot_configuration.number_of_wheels;
    num_contacts_per_wheel = robot_configuration.number_of_contacts_per_wheel;

    // Initialize filter with the initial state and noise parameters
    odometry.initialize(initial_state, noise_params);
    std::cout << "Robot's state is initialized to: \n";
    print_state(odometry.getState());  //TODO: change this so << operator can be used for printing the state

    // set the robot configuration for the odometry object 
    odometry.setRobotConfiguration(robot_configuration);

    wheel_frame_names = _wheel_frame_names.value();
    wheel_frame_fixed_names = _wheel_frame_fixed_names.value();

    measurement_imu_valid = false;
    pose_imu_valid = false;
    
    gyro_bias_estimation_time = _gyro_bias_estimation_time.get();
    gyro_bias_estimation_completed = false;
    gyro_bias_set = false;
    
    // set the bias estimation flag in the odometry object(this resets the bias estimate to zero every propagation step)
    odometry.setEstimateBias(_bias_estimation_in_propagation_step.get());
    
    // Initialize dynamic transformation vectors
    contact_frame_transformations.clear();
    contact_frame_transforms.clear();
    wheel_frame_fixed_transformations.clear();
    wheel_frame_fixed_transforms.clear();

    imu_body_estimated.gyro.setZero();
    imu_body_estimated.acc.setZero();
    pose_body_estimated.targetFrame = _world_frame.get();
    pose_body_estimated.sourceFrame = _body_frame.get();
    
    body_frame = _body_frame.get();
    contact_frame_names = _contact_frame_names.value();


    // check the validity of the input parameters
    if (contact_frame_names.size() != robot_configuration.number_of_wheels * robot_configuration.number_of_contacts_per_wheel) {
        std::cout << "contact frames - " << contact_frame_names.size() << " " << "no. of wheels * contacts per wheel - " << robot_configuration.number_of_wheels * robot_configuration.number_of_contacts_per_wheel << std::endl;
        std::cerr << "Error: The number of contact frames must be equal to number_of_wheels * number_of_contacts_per_wheel!" << std::endl;
        return false;
    }

    if (wheel_frame_fixed_names.size() != robot_configuration.number_of_wheels ||
        wheel_frame_names.size() != robot_configuration.number_of_wheels) {
        std::cerr << "Error: Wheel frame vectors must match number_of_wheels!" << std::endl;
        return false;
    }

    if (wheel_frame_names.empty() || wheel_frame_fixed_names.empty()) {
        std::cerr << "No wheel frame names provided, assuming non-wheeled system..." << std::endl;
        wheeled_system = false;
    }
    
    printProperties();


    return true;
}
bool Task::startHook()
{
    if (! TaskBase::startHook())
        return false;
    if(debug){
        debug_iteration_start_time = base::Time::now();
    }

    return true;
}

void Task::updateHook()
{
    TaskBase::updateHook();
}
void Task::errorHook()
{
    TaskBase::errorHook();
}
void Task::stopHook()
{
    TaskBase::stopHook();
}
void Task::cleanupHook()
{
    TaskBase::cleanupHook();
}

void Task::printProperties()
{
    std::cout << "Current properties: " << std::endl;
    std::cout << "================================" << std::endl;
    std::cout << "-----------------------" << std::endl;
    std::cout << "Noise parameters: " << std::endl;
    std::cout << "Gyroscope noise: " << noise_params.noise_gyroscope << std::endl;
    std::cout << "Accelerometer noise: " << noise_params.noise_accelerometer << std::endl;
    std::cout << "Gyroscope bias noise: " << noise_params.noise_gyroscope_bias << std::endl;
    std::cout << "Accelerometer bias noise: " << noise_params.noise_accelerometer_bias << std::endl;
    std::cout << "-----------------------" << std::endl;
    std::cout << "Measurement noise: " << _measurement_noise.get() << std::endl;
    std::cout << "Chi-squared threshold: " << _chi_squared_threshold.get() << std::endl;
    std::cout << "Contact MD squared threshold: " << _contact_md2_threshold.get() << std::endl;
    std::cout << "-----------------------" << std::endl;
    std::cout << "Estimate contacts: " << _estimate_contacts.get() << std::endl;
    std::cout << "Enable multi-contact estimation: " << _enable_multi_contact_estimation.get() << std::endl;
    std::cout << "Bias estimation in the propagation step: " << _bias_estimation_in_propagation_step.get() << std::endl;
    std::cout << "PCV gyro bias correction enabled: " << _enable_pcv_gyro_bias_correction.get() << std::endl;
    std::cout << "Gyro bias estimation time: " << _gyro_bias_estimation_time.get() << " seconds" << std::endl;
    std::cout << "================================" << std::endl;
}


static double yawFromRotation(const Eigen::Matrix3d& R)
{
    return std::atan2(R(1,0), R(0,0));
}

static double rad2deg(double x)
{
    return x * 180.0 / M_PI;
}

int Task::getContactFramesTransforms(const base::Time &ts, bool debug)
{
    // Get the transformation of contact frames in body frame and store them in contact_frame_transforms as Eigen::Affine3d

    // Initialize contact frame transformations if not already done
    if (contact_frame_transformations.size() != contact_frame_names.size()) {
        // Clear existing transformations
        contact_frame_transformations.clear();
        contact_frame_transforms.clear();
        
        // Register new transformations for each contact frame
        for (const auto& name : contact_frame_names) {
            transformer::Transformation& trans = _transformer.registerTransformation(name, body_frame);
            contact_frame_transformations.push_back(&trans);
            contact_frame_transforms.push_back(Eigen::Affine3d::Identity());
        }
    }

    // CHECK transforms to output port to check the validity of the values 
    
    // Get all contact frame transformations
    for (size_t i = 0; i < contact_frame_names.size(); ++i) {
        if (!contact_frame_transformations[i]->get(ts, contact_frame_transforms[i], true)) {
            if (debug) {
                 std::cout << "Failed to get transformation for contact frame: " << contact_frame_names[i] << " at " << ts.toSeconds() << " seconds." << std::endl;
                 std::cout << "Skipping contact velocity correction step." << std::endl;
            }
            return 1;
        }
        else {
            if(debug){std::cout << "Successfully got transformation for contact frame: " << contact_frame_names[i] << " at " << ts.toSeconds() << " seconds." << std::endl;}
        }
    }
    return 0;
}

int Task::getWheelFramesFixedTransforms(const base::Time &ts, bool debug)
{

    // Get the transformation of wheels in body frame in Eigen::Affine3d

    if (wheel_frame_fixed_names.empty()) {
        if(debug){
            std::cerr << "No wheel frames defined." << std::endl;
        }
        return 1;
    }

    // Initialize wheel frame transformations if not already done
    if (wheel_frame_fixed_transformations.size() != wheel_frame_fixed_names.size()) {
        // Clear existing transformations
        wheel_frame_fixed_transformations.clear();
        wheel_frame_fixed_transforms.clear();

        // Register new transformations for each wheel frame
        for (const auto& name : wheel_frame_fixed_names) {
            transformer::Transformation& trans = _transformer.registerTransformation(name, body_frame); //TODO: Dont set this twice, instead write a big list of variables and bind them to this list in a function.
            wheel_frame_fixed_transformations.push_back(&trans);
            wheel_frame_fixed_transforms.push_back(Eigen::Affine3d::Identity());
        }
    }
    // Get all wheel frame transformations
    for (size_t i = 0; i < wheel_frame_fixed_names.size(); ++i) {
        if (!wheel_frame_fixed_transformations[i]->get(ts, wheel_frame_fixed_transforms[i], true)) {
            if (debug) {
                std::cout << "Failed to get transformation for wheel frame: " << wheel_frame_fixed_names[i] << " at " << ts.toSeconds() << " seconds." << std::endl;
                std::cout << "Skipping contact velocity correction step." << std::endl;
            }
            return 1;
        }
        else{
            if(debug){std::cout << "Successfully got transformation for wheel frame: " << wheel_frame_fixed_names[i] << std::endl;}   
        }
    }
    return 0;
}

int Task::getFoot2WheelFixedFramesTransforms(const base::Time &ts, bool debug)
{

    // Get the transformation of wheels in body frame in Eigen::Affine3d
    if (wheel_frame_fixed_names.empty()) {
        if(debug){
            std::cerr << "No wheel frames defined." << std::endl;
        }
        return 1;
    }
            
    if (feet_to_fixed_wheel_frames_transformations.size() != contact_frame_names.size()) {
        
        // num wheels = wheel_frame_fixed_names.size()
        // num contacts per wheel = contact_frame_names.size() / wheel_frame_fixed_names.size()
        // Assumption: the order of wheel frame names and the contact frame names are consistent, fl, rl, fr, rr in four wheeled system 
        
        feet_to_fixed_wheel_frames_transformations.clear();
        feet_to_fixed_wheel_frames_transforms.clear();
                
        for (int i=0; i < num_wheels; i++) {
            for (int j=0; j< num_contacts_per_wheel; j++) {
        
            transformer::Transformation& trans = _transformer.registerTransformation(contact_frame_names[i*num_contacts_per_wheel + j], wheel_frame_fixed_names[i]); //TODO: Dont set this twice, instead write a big list of variables and bind them to this list in a function.
            feet_to_fixed_wheel_frames_transformations.push_back(&trans);
            feet_to_fixed_wheel_frames_transforms.push_back(Eigen::Affine3d::Identity());                                      
            }
        }
    }
    // Get all foot to wheel frame transformations
    for (size_t i = 0; i < wheel_frame_fixed_names.size(); ++i) {
        for (size_t j = 0; j < num_contacts_per_wheel; ++j) {
            int contact_index = i * num_contacts_per_wheel + j;
            if (!feet_to_fixed_wheel_frames_transformations[contact_index]->get(ts, feet_to_fixed_wheel_frames_transforms[contact_index], true)) {
                if (debug) {
                    std::cout << "Failed to get transformation for foot to fixed wheel frame: " << contact_frame_names[contact_index] << " to " << wheel_frame_fixed_names[i] << " at " << ts.toSeconds() << " seconds." << std::endl;
                    std::cout << "Skipping contact velocity correction step." << std::endl;
                }
                return 1;
            }
            else {
                if(debug){std::cout << "Successfully got transformation for foot to fixed wheel frame: " << contact_frame_names[contact_index] << " to " << wheel_frame_fixed_names[i] << std::endl;}
            }
        }
    }
    return 0;
}

int Task::constructKinematics(const base::Time ts, const base::samples::Joints joints)

{
    // ----------------------- Getting wheel speeds -------------
    if (wheeled_system) {
        if (joints.size() < wheel_frame_names.size()) {
            if (debug) {
                std::cout << "Not enough joints received" << std::endl;
                std::cout << "Expected at least " << wheel_frame_names.size() << " joints, but received " << joints.size() << std::endl;
            }
            return 1;
        }
        else {
            wheel_names_speed_map.clear();
            for (size_t i = 0; i < wheel_frame_names.size(); i++) {
                if (joints[wheel_frame_names[i]].hasSpeed()) {
                    // Create a map of wheel names and speed 
                    wheel_names_speed_map.push_back(std::make_pair(wheel_frame_names[i], joints[wheel_frame_names[i]].speed));
                    
                    if(debug){std::cout << "[DEBUG] " << wheel_frame_names[i] << "Wheel" << "has speed of: " << joints[wheel_frame_names[i]].speed << " from joint data " << std::endl;}
                }
                else {
                    if(debug){std::cout << "[DEBUG] Joint " << wheel_frame_names[i] << " does not have speed information, skipping..." << std::endl;}
                }
            }
        }
    }
    else {
        std::cerr << "Not a wheeled system, Incomplete Implementation for non wheeled system" << std::endl;
        return 1;
    }
    
    // ----------------------- Get Kinematics --------------------
    
    int contact_frames_result = getContactFramesTransforms(ts, debug);
    int wheel_frames_result = getWheelFramesFixedTransforms(ts, debug);
    int foot2wheel_frames_result = getFoot2WheelFixedFramesTransforms(ts, debug);
    
    if (contact_frames_result != 0 || wheel_frames_result != 0 || foot2wheel_frames_result != 0) {
        if (debug) {
            std::cout << "Failed to get necessary transformations for kinematics construction." << std::endl;
        }
        return 1;
    }
    
    return 0;
}

void Task::joint_stateTransformerCallback(const base::Time &ts, const base::samples::Joints &joints)
{

    if (joints.size() == 0) {
        std::cout << "No joints received in joint state callback" << std::endl;
    }
    else {    
        int ok = constructKinematics(ts, joints);
        if (ok != 0) {
            std::cerr << "Failed to construct kinematics in joint state callback at time " << ts.toSeconds() << " seconds." << std::endl;
        }
    }
}

void Task::readInputPortReferences()
{
    // Read the pose of the IMU wrt. the body frame
    while ( _pose_imu.read( pose_imu, false ) == RTT::NewData ) {
        pose_imu_valid = true;
    }
}

void Task::measurement_imuTransformerCallback(const base::Time &ts, const base::samples::IMUSensors &imu_cb)
{
           
    readInputPortReferences();

    measureIMU(imu_cb);
    
    if (!gyro_bias_estimation_completed && measurement_imu_valid) {
        measureGyroBias();
    }
    else if (gyro_bias_estimation_completed && !gyro_bias_set) {
        setInitialGyroBias();
        Eigen::Vector3d acc_body_corrected =
        pose_imu.orientation * measurement_imu.acc - estimated_acc_bias; // corrected accelerometer measurement in body frame

        std::cout << "[INFO] Corrected stationary acc body: "
            << acc_body_corrected.transpose()
            << std::endl;
            
        std::cout << "[INFO] Estimated acc bias: "
            << estimated_acc_bias.transpose()
            << std::endl;
    } 

    if (gyro_bias_estimation_completed && gyro_bias_set) {
        
    // This is to fix the issue of the gyro bias being reset to zero in every propagation step
    if (!_bias_estimation_in_propagation_step.get() && fixed_gyro_bias_valid)
    {
        odometry.setGyroscopeBias(fixed_gyro_bias_body);
    }
    if (!_bias_estimation_in_propagation_step.get() && fixed_acc_bias_valid)
    {
        odometry.setAccelerometerBias(fixed_acc_bias_body);
    }
    // //propagate the state with IMU measurement
    propagateIMU();
    
    state_covariance_propagation = odometry.getStateCovariance(); // for debugging, to check if the covariance is being updated properly
    base::MatrixXd debug_cov_propagation = state_covariance_propagation; 
    _debug_state_covariance_propagation.write(state_covariance_propagation); // write the state covariance after propagation to debug port
    // //correct the state with contact velocity correction step
    
    contact_velocity_odometry::RobotState state_before_corr = odometry.getState();
    double yaw_before_corr = yawFromRotation(state_before_corr.rotation);

    correctContactVelocity();

    contact_velocity_odometry::RobotState state_after_corr = odometry.getState();
    double yaw_after_corr = yawFromRotation(state_after_corr.rotation);

    static int corr_debug_counter = 0;
    if (corr_debug_counter++ % 20 == 0)
    {
        std::cout << std::fixed << std::setprecision(8);
        std::cout << "[YAW_DEBUG_CORR] t_log=" << measurement_imu.time.toSeconds()
                << " yaw_before_corr_deg=" << rad2deg(yaw_before_corr)
                << " yaw_after_corr_deg=" << rad2deg(yaw_after_corr)
                << " corr_delta_yaw_deg=" << rad2deg(yaw_after_corr - yaw_before_corr)
                << " bg_before=" << state_before_corr.gyroscope_bias.transpose()
                << " bg_after=" << state_after_corr.gyroscope_bias.transpose()
                << " bg_delta=" << (state_after_corr.gyroscope_bias - state_before_corr.gyroscope_bias).transpose()
                << std::endl;
    }

    state_covariance_correction = odometry.getStateCovariance(); // for debugging, to check if the covariance is being updated properly
    base::MatrixXd debug_cov_correction = state_covariance_correction;
    _debug_state_covariance_correction.write(state_covariance_correction); // write the state covariance after correction to debug port

    
    if (!_bias_estimation_in_propagation_step.get() && fixed_gyro_bias_valid)
    {
        odometry.setGyroscopeBias(fixed_gyro_bias_body);
    }
    if (!_bias_estimation_in_propagation_step.get() && fixed_acc_bias_valid)
    {
        odometry.setAccelerometerBias(fixed_acc_bias_body);
    }
    // // write the output to ports
    writeOutput();
    }

}

void Task::measureIMU(base::samples::IMUSensors measurement_imu_cb)
{

    // Update the gyro vector for bias estimation in the member variable
    measurement_imu = measurement_imu_cb;
    gyro_vector = measurement_imu.gyro;
    acc_vector = measurement_imu.acc;

    // Convert the IMU measurement to body frame for debugging purposes
    // MAKING A NEW PORT FOR THIS PURPOSE SHOULD BE THE RIGHT WAY TO DO IT, BUT FOR NOW, JUST WRITING TO THE DEBUG PORT
    
    base::samples::IMUSensors body_oriented_imu;
    
    if (debug){
        std::cout << "[DEBUG] Raw Gyroscope : " << measurement_imu.gyro.transpose() << std::endl;
        std::cout << "[DEBUG] Raw Accelerometer:  " << measurement_imu.acc.transpose() << std::endl;
    }
    
    body_oriented_imu = measurement_imu;
    body_oriented_imu.gyro = pose_imu.orientation * measurement_imu.gyro;
    body_oriented_imu.acc = pose_imu.orientation * measurement_imu.acc;
    
    _debug_measurement_imu.write( body_oriented_imu );
    
    imu_dt = (measurement_imu.time - measurement_imu_prev.time).toSeconds();
    
    if (pose_imu_valid) 
    {
        // converting the IMU measurement for the IMU frame to body frame 
        measurement_imu_vector.head<3>() = pose_imu.orientation * measurement_imu_prev.gyro;
        measurement_imu_vector.tail<3>() = pose_imu.orientation * measurement_imu_prev.acc;

        // Update the gyro vector for bias estimation in the member variable 
    }
    measurement_imu_valid = true;
    measurement_imu_prev = measurement_imu;
}

void Task::measureGyroBias()
{
            
    // calibrate gyro bias during the first few seconds of operation when the robot is expected to be stationary. 
    // Start the bias estimation timer 
    if (!gyro_bias_estimation_started) {
        gyro_bias_estimation_start_time = measurement_imu.time;
        gyro_bias_estimation_started = true;
    }
        
    // If we are still within the bias estimation time window, accumulate gyro measurements to estimate bias
    if ((measurement_imu.time - gyro_bias_estimation_start_time).toSeconds() < gyro_bias_estimation_time) {
        if (gyro_vector.norm() < 0.01) { // use 0.01 rad/s as a threshold to consider that the robot is stationary
            if (debug) {std::cout << "Collecting gyro measurements for bias estimation: " << gyro_vector.transpose() << std::endl;}
            accumulated_gyro_measurements.push_back(gyro_vector);
            accumulated_acc_measurements.push_back(acc_vector);

        }
        else{
            if (debug) {std::cout << "[DEBUG] Unreasonable gyro vector value: " << gyro_vector.transpose() << " Ignored from bias estimation" << std::endl;}
        }
        gyro_bias_estimation_completed = false;
    }
    else{
        if (debug) {std::cout << "[DEBUG] Gyro bias estimation time window ended. Calculating bias estimate..." << std::endl;}
        if (accumulated_gyro_measurements.size() >= 10) { // require at least 10 measurements for a reliable bias estimate
            // Calculate the initial gyro bias as the mean of accumulated measurements
            // Calculate the average of the accumulated gyro measurements to get the bias estimate
            estimated_gyro_bias.setZero();
            
            // take the average of the accumulated gyro measurements
            for (const auto& measurement : accumulated_gyro_measurements) {
                estimated_gyro_bias += measurement;
            }
            estimated_gyro_bias /= static_cast<double>(accumulated_gyro_measurements.size());
            gyro_bias_estimation_completed = true;
            //clear the accumulated measurements after estimation is completed

            std::cout << "[INFO] Gyro bias estimation completed. Estimated bias: " << estimated_gyro_bias.transpose() << std::endl;
            std::cout << "[INFO] Number of measurements used for bias estimation: " << accumulated_gyro_measurements.size() << std::endl;
            // std::cout << "[DEBUG] Variance of accumulated gyro measurements: " << variance(accumulated_gyro_measurements).transpose() << std::endl;
            
            accumulated_gyro_measurements.clear(); 
            
        if (accumulated_acc_measurements.size() >= 10) {
            Eigen::Vector3d mean_acc_imu = Eigen::Vector3d::Zero();

            for (const auto& measurement : accumulated_acc_measurements) {
                mean_acc_imu += measurement;
            }

            mean_acc_imu /= static_cast<double>(accumulated_acc_measurements.size());

            // Convert measured mean acceleration to body frame
            Eigen::Vector3d mean_acc_body = pose_imu.orientation * mean_acc_imu;

            // Expected stationary accelerometer measurement in body frame
            Eigen::Vector3d expected_acc_body(0.0, 0.0, 9.81);

            // Bias in body frame
            estimated_acc_bias = mean_acc_body - expected_acc_body;
            // set x and y components of estimated_acc_bias to zero, 
            
            estimated_acc_bias.x() = 0.0;
            estimated_acc_bias.y() = 0.0;

            std::cout << "[INFO] Mean acc IMU frame: "
                    << mean_acc_imu.transpose() << std::endl;

            std::cout << "[INFO] Mean acc body frame: "
                    << mean_acc_body.transpose() << std::endl;

            std::cout << "[INFO] Expected acc body frame: "
                    << expected_acc_body.transpose() << std::endl;

            std::cout << "[INFO] Estimated acc bias body frame: "
                    << estimated_acc_bias.transpose() << std::endl;
        }
        }
        else{
            std::cerr << "[ERROR] No gyro measurements received for bias estimation" << std::endl;
        }
    }
}

void Task::setInitialGyroBias()
{
    if (!pose_imu_valid) {
        std::cerr << "[ERROR] Pose of IMU in body frame is not valid, cannot set gyro bias in the state!" << std::endl;
        return;
    }

    Eigen::Vector3d bg_body = pose_imu.orientation * estimated_gyro_bias;
    Eigen::Vector3d ba_body = estimated_acc_bias; // already in body frame
    
    if (set_initial_gyro_bias_estimate) {
        odometry.setGyroscopeBias(bg_body);
        fixed_gyro_bias_body = bg_body;
        fixed_gyro_bias_valid = true;
    }
    else{
        std::cout << "[INFO] Not setting initial gyro bias estimate in the state, as per the property setting." << std::endl;
    }
    if (set_initial_acc_bias_estimate) {
        fixed_acc_bias_body = ba_body;
        fixed_acc_bias_valid = true;
        odometry.setAccelerometerBias(ba_body);
    }
    else{
        std::cout << "[INFO] Not setting initial accelerometer bias estimate in the state, as per the property setting." << std::endl;
    }

    gyro_bias_set = true;

    Eigen::Vector3d gyro_body_now = pose_imu.orientation * measurement_imu.gyro;
    Eigen::Vector3d gyro_corrected_now = gyro_body_now - bg_body;

    std::cout << std::fixed << std::setprecision(8);
    std::cout << "[YAW_DEBUG_BIAS_SET] t_log=" << measurement_imu.time.toSeconds()
            << " gyro_raw_imu=" << measurement_imu.gyro.transpose()
            << " gyro_body=" << gyro_body_now.transpose()
            << " bg_body=" << bg_body.transpose()
            << " gyro_corrected_body=" << gyro_corrected_now.transpose()
            << " gyro_corrected_z_deg_s=" << rad2deg(gyro_corrected_now.z())
            << std::endl;
}

void Task::propagateIMU()
{
    if (measurement_imu_valid && pose_imu_valid) {
        
        if ( debug ) {
           std::cout << "[DEBUG] Body oriented Gyroscope : " << measurement_imu_vector.segment<3>(0).transpose() << std::endl;
           std::cout << "[DEBUG] Body oriented Accelerometer:  " << measurement_imu_vector.segment<3>(3).transpose() << std::endl;
        }
        if (imu_dt > 0.0009 && imu_dt < 0.1) {
        contact_velocity_odometry::RobotState state_before = odometry.getState();

        double yaw_before = yawFromRotation(state_before.rotation);

        Eigen::Vector3d gyro_body = measurement_imu_vector.head<3>();
        Eigen::Vector3d gyro_corrected = gyro_body - state_before.gyroscope_bias;

        double predicted_dyaw = gyro_corrected.z() * imu_dt;

        odometry.propagate(measurement_imu_vector, imu_dt);

        contact_velocity_odometry::RobotState state_after = odometry.getState();
        double yaw_after = yawFromRotation(state_after.rotation);

        static int prop_debug_counter = 0;
        if (prop_debug_counter++ % 20 == 0)
        {
            std::cout << std::fixed << std::setprecision(8);
            std::cout << "[YAW_DEBUG_PROP] t_log=" << measurement_imu.time.toSeconds()
                    << " dt=" << imu_dt
                    << " gyro_body=" << gyro_body.transpose()
                    << " bg=" << state_before.gyroscope_bias.transpose()
                    << " gyro_corrected=" << gyro_corrected.transpose()
                    << " predicted_dyaw_deg=" << rad2deg(predicted_dyaw)
                    << " yaw_before_deg=" << rad2deg(yaw_before)
                    << " yaw_after_deg=" << rad2deg(yaw_after)
                    << " actual_dyaw_deg=" << rad2deg(yaw_after - yaw_before)
                    << std::endl;
        }
            if( debug )
                std::cout << "[DEBUG] Propagate with dt " << imu_dt << std::endl;
        }
        else if ( debug ) {
            std::cout << "[DEBUG] NOT propagate because of dt " << imu_dt << std::endl;
        }
    }
}

void Task::correctContactVelocity()
{
   
    if ( !wheeled_system) {
        std::cerr << "[Warning]Non wheeled system Not implemented, skipping contact velocity correction" << std::endl;
        return;
    }
    
    if ( !measurement_imu_valid ) {
        std::cerr << "No IMU data received, skipping contact velocity correction" << std::endl;
        return;
    }

    if ( wheel_names_speed_map.empty() ) {
        std::cerr << "No wheel speed information received, skipping contact velocity correction" << std::endl;
        return;
    }

    // print the wheel speeds map for debug
    if (debug) {
        std::cout << "[DEBUG] Wheel Speeds: " << std::endl;
        for (const auto& wheel_speed : wheel_names_speed_map) {
            std::cout << "  " << wheel_speed.first << ": " << wheel_speed.second << std::endl;
        }
    }
    
    // Call the correct contact velocity function with the calculated parameters
    iteration_counter += 1;
    if(debug){std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << "\n";}
    if(debug){std::cout << "Iteration number: " << iteration_counter << "\n";
        // elapsed time 
        double elapsed_time = (base::Time::now() - debug_iteration_start_time).toSeconds();
        std::cout << "Elapsed time so far: " << elapsed_time << " seconds" << std::endl;
        std::cout << "Timestamp of this iteration: " << base::Time::now().toSeconds() << " seconds" << std::endl;
    }
    // set time for contact states
    lf_selected_contacts.time = measurement_imu.time;
    md_selected_contacts.time = measurement_imu.time;
    
    Eigen::Vector3d gyro_vector_body = pose_imu.orientation * measurement_imu.gyro;
    odometry.correctContactVelocity(wheel_names_speed_map, 
                                    contact_frame_transforms,
                                    wheel_frame_fixed_transforms,
                                    feet_to_fixed_wheel_frames_transforms, 
                                    gyro_vector_body,
                                    measurement_noise,
                                    chi_squared_threshold,
                                    contact_md2_threshold,
                                    estimate_contacts,
                                    enable_multi_contact_estimation,
                                    pcv_gyro_bias_correction_enabled,
                                    reject_slipping_spokes,
                                    lf_selected_contacts,
                                    md_selected_contacts,
                                    mahalanobis_distances_for_all_wheels,
                                    slipping_spokes,
                                    debug);

    if(debug){std::cout << "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" << "\n";}
}

void Task::writeOutput()
{
    
    if (debug) {
        std::cout << "[DEBUG] Writing output ports..." << std::endl;
    }
    contact_velocity_odometry::RobotState state = odometry.getState();

    // Pose_body_estimated output port
    pose_body_estimated.time = measurement_imu.time;
    pose_body_estimated.orientation = base::Quaterniond( state.rotation ); 
    pose_body_estimated.position = state.position;
    pose_body_estimated.velocity = state.velocity;

    pose_body_estimated.angular_velocity.setZero();
    if (measurement_imu_valid && pose_imu_valid) {       
        // since state.gyroscope_bias is in body frame, we can directly subtract it from the measurement_imu.gyro 
        pose_body_estimated.angular_velocity = pose_body_estimated.orientation * ((pose_imu.orientation * measurement_imu.gyro) - state.gyroscope_bias);
    }

    Eigen::MatrixXd P = odometry.getStateCovariance();
    pose_body_estimated.cov_orientation = P.block<3,3>(0,0);
    pose_body_estimated.cov_velocity = P.block<3,3>(3,3);
    pose_body_estimated.cov_position = P.block<3,3>(6,6);

    _pose_body_estimated.write( pose_body_estimated );

    // Pose_body_estimated_local output port
    pose_body_estimated_local.time = measurement_imu.time;
    pose_body_estimated_local.orientation = pose_body_estimated.orientation;
    pose_body_estimated_local.position = pose_body_estimated.orientation.inverse() * state.position;
    pose_body_estimated_local.velocity = pose_body_estimated.orientation.inverse() * state.velocity;
    if (measurement_imu_valid && pose_imu_valid) {       
        // since state.gyroscope_bias is in body frame, we can directly subtract it from the measurement_imu.gyro 
        pose_body_estimated_local.angular_velocity = (pose_imu.orientation * measurement_imu.gyro) - state.gyroscope_bias;
    }

    // need to check how to include the covariance in the local frame output port
    _pose_body_estimated_local.write( pose_body_estimated_local );

    // IMU estimated output ports
    if (measurement_imu_valid && pose_imu_valid) {            
        imu_body_estimated.time = pose_body_estimated.time;
        imu_body_estimated.gyro = pose_imu.orientation * measurement_imu.gyro - state.gyroscope_bias;
        imu_body_estimated.acc = pose_imu.orientation * measurement_imu.acc - state.accelerometer_bias;

        _imu_body_estimated.write( imu_body_estimated );
        
        imu_world_estimated.gyro = state.rotation * imu_body_estimated.gyro;
        base::Vector3d g;
        g << 0,0,-9.81;
        imu_world_estimated.acc = state.rotation * imu_body_estimated.acc + g;
        imu_world_estimated.time = pose_body_estimated.time;

        _imu_world_estimated.write( imu_world_estimated );
    }

    // IMU bias estimated output port
    imu_bias_estimated.time = pose_body_estimated.time;
    imu_bias_estimated.gyro = state.gyroscope_bias;
    imu_bias_estimated.acc = state.accelerometer_bias;

    _imu_bias_estimated.write( imu_bias_estimated );

    // Selected contacts output port
    _debug_md_contact_points.write( md_selected_contacts );
    _debug_lf_contact_points.write( lf_selected_contacts );
    _debug_kalman_gain.write( odometry.getKalmanGain() );
    _debug_innovations.write( odometry.getInnovations() );
    
    _debug_md2_distances_for_all_wheels.write( mahalanobis_distances_for_all_wheels );
    _debug_slipping_spokes.write( slipping_spokes );
}