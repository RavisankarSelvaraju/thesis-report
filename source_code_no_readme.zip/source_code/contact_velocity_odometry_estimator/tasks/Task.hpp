/* Generated from orogen/lib/orogen/templates/tasks/Task.hpp */

#ifndef CONTACT_VELOCITY_ODOMETRY_ESTIMATOR_TASK_TASK_HPP
#define CONTACT_VELOCITY_ODOMETRY_ESTIMATOR_TASK_TASK_HPP

#include "contact_velocity_odometry_estimator/TaskBase.hpp"
#include <unistd.h>
#include <unordered_map>
#include <mutex>
#include <numeric>
#include <base/Timeout.hpp>
#include <iomanip>
#include <cmath>

#include <contact_velocity_odometry/ContactVelocityOdometry.hpp>
#include "contact_velocity_odometry/ContactVelocityOdometry_Types.hpp"
#include <transformer/TransformationStatus.hpp>
#include <transformer/Transformer.hpp>
#include <odometry/ContactState.hpp>

namespace contact_velocity_odometry_estimator{

    /*! \class Task
     * \brief The task context provides and requires services. It uses an ExecutionEngine to perform its functions.
     * Essential interfaces are operations, data flow ports and properties. These interfaces have been defined using the oroGen specification.
     * In order to modify the interfaces you should (re)use oroGen and rely on the associated workflow.
     * 
     * \details
     * The name of a TaskContext is primarily defined via:
     \verbatim
     deployment 'deployment_name'
         task('custom_task_name','contact_velocity_odometry_estimator::Task')
     end
     \endverbatim
     *  It can be dynamically adapted when the deployment is called with a prefix argument.
     */
    class Task : public TaskBase
    {
	friend class TaskBase;
    protected:
        void joint_stateTransformerCallback(const base::Time &ts, const base::samples::Joints &joints);
        void measurement_imuTransformerCallback(const base::Time &ts, const base::samples::IMUSensors &imu);

        // ----- ----- ----- debug flag ----- ----- -----
        bool debug = false;
        base::Time debug_iteration_start_time;
        bool wheeled_system = true; // assume wheeled system
        Eigen::MatrixXd state_covariance_propagation; // for debugging, to check if the covariance is being updated properly
        Eigen::MatrixXd state_covariance_correction; // for debugging, to check if the covariance is being updated properly

        // ----- ----- ----- initial setup variables ----- ----- -----
        contact_velocity_odometry::Odometry odometry;   // change the name to avoid conflict with odometry namespace TODO
        contact_velocity_odometry::RobotState initial_state; 
        contact_velocity_odometry::NoiseParams noise_params;      

        Eigen::Matrix3d R0;
        Eigen::Vector3d v0, p0, bg0, ba0;

        // ----- ----- ----- IMU variables ----- ----- -----
        double imu_dt = 0.0;        
        bool pose_imu_valid;
        bool measurement_imu_valid;
        Eigen::Matrix<double,6,1> measurement_imu_vector;
        base::samples::RigidBodyState pose_imu; // variable for input port data
        base::samples::IMUSensors measurement_imu; // variable for input port data
        base::samples::IMUSensors measurement_imu_prev;

        // ----- ----- ----- Gyro bias estimation variables ----- ----- -----
        Eigen::Vector3d gyro_vector = Eigen::Vector3d::Zero();
        Eigen::Vector3d estimated_gyro_bias = Eigen::Vector3d::Zero();

        Eigen::Vector3d acc_vector = Eigen::Vector3d::Zero();
        Eigen::Vector3d estimated_acc_bias = Eigen::Vector3d::Zero();

        bool gyro_bias_estimation_completed = false;
        bool gyro_bias_set = false;        
        bool gyro_bias_estimation_started = false;
        base::Time gyro_bias_estimation_start_time;
        double gyro_bias_estimation_time = 2.0; // time window for gyro bias estimation in seconds
        
        std::vector<Eigen::Vector3d> accumulated_acc_measurements;
        std::vector<Eigen::Vector3d> accumulated_gyro_measurements;

        // ----- ----- ----- properties variables ----- ----- -----
        std::string robot_urdf_path;
        std::string body_frame;

        // ----- ----- ----- internal variables ----- ----- -----
        size_t num_contacts_per_wheel;
        size_t num_wheels;
        size_t iteration_counter = 0;
        double measurement_noise = 0.001; // default measurement noise for contact velocity correction
        double chi_squared_threshold = 7.815; // default chi-squared threshold for
        double contact_md2_threshold = 2.0; // threshold to determine if multiple spokes are in contact based on their MD distance difference
        bool estimate_contacts = true; // whether to perform contact estimation or not
        bool enable_multi_contact_estimation = true; // whether to perform multi-contact estimation or not
        bool reject_slipping_spokes = true; // whether to reject spokes that are slipping based on their MD distance from the update step
        bool set_initial_acc_bias_estimate = true; // whether to set the initial accelerometer bias estimate in the state or not
        bool set_initial_gyro_bias_estimate = true; // whether to set the initial gyroscope bias estimate in the state or not
        
        bool pcv_gyro_bias_correction_enabled = true; 
        Eigen::Vector3d fixed_gyro_bias_body;
        bool fixed_gyro_bias_valid = false;
        Eigen::Vector3d fixed_acc_bias_body;
        bool fixed_acc_bias_valid = false;
        // ----- ----- ----- Correction step variables ----- ----- -----
        std::vector<std::string> contact_frame_names;
        std::vector<std::string> contact_sensor_names;

        std::vector<std::string> wheel_frame_names;
        std::vector<std::string> wheel_frame_fixed_names;

        std::vector<std::pair<std::string, float>> wheel_names_speed_map;

        std::unordered_map<std::string, size_t> contact_sensor_names_to_in_contact_idx;

        // ----- ----- ----- Dynamic contact and wheel frame transformations ----- ----- -----
        std::vector<transformer::Transformation*> contact_frame_transformations;
        std::vector<Eigen::Affine3d> contact_frame_transforms;
        
        std::vector<transformer::Transformation*> wheel_frame_fixed_transformations;
        std::vector<Eigen::Affine3d> wheel_frame_fixed_transforms;
        
        std::vector<transformer::Transformation*> feet_to_fixed_wheel_frames_transformations;
        std::vector<Eigen::Affine3d> feet_to_fixed_wheel_frames_transforms;

        // ----- ----- ----- Output port variables ----- ----- -----
        base::samples::RigidBodyState pose_body_estimated;
        base::samples::RigidBodyState pose_body_estimated_local;
        base::samples::IMUSensors imu_body_estimated;
        base::samples::IMUSensors imu_world_estimated;
        base::samples::IMUSensors imu_bias_estimated;
        odometry::BodyContactState lf_selected_contacts;
        odometry::BodyContactState md_selected_contacts; 
        std::vector<double> mahalanobis_distances_for_all_wheels; // for debugging, to check the MD distances for all wheels and 
        std::vector<size_t> slipping_spokes; // for debugging, the global indices of the spokes that are slipping based on the MD distance threshold

        void inline print_state(const contact_velocity_odometry::RobotState& state){
            std::cout << "Position: \n" << state.position.transpose() << std::endl;
            std::cout << "Velocity: \n" << state.velocity.transpose() << std::endl;
            std::cout << "Rotation: \n" << state.rotation << std::endl;
            std::cout << "Gyro bias: \n" << state.gyroscope_bias.transpose() << std::endl;
            std::cout << "Acc bias: \n" << state.accelerometer_bias.transpose() << std::endl;
        }

        void printProperties();
        void readInputPortReferences();
        void measureIMU(base::samples::IMUSensors measurement_imu);
        void measureGyroBias();
        void setInitialGyroBias();
        void propagateIMU();
        void writeOutput();
        void correctContactVelocity();


        // ----- ----- ----- Helper functions for correction step ----- ----- -----
        int constructKinematics(const base::Time ts, const base::samples::Joints joints);
        int getContactFramesTransforms(const base::Time &ts, bool debug);
        int getWheelFramesFixedTransforms(const base::Time &ts, bool debug);
        int getFoot2WheelFixedFramesTransforms(const base::Time &ts, bool debug);

    public:
        /** TaskContext constructor for Task
         * \param name Name of the task. This name needs to be unique to make it identifiable via nameservices.
         * \param initial_state The initial TaskState of the TaskContext. Default is Stopped state.
         */
        Task(std::string const& name = "contact_velocity_odometry_estimator::Task");

        /** Default deconstructor of Task
         */
	~Task();

        /** This hook is called by Orocos when the state machine transitions
         * from PreOperational to Stopped. If it returns false, then the
         * component will stay in PreOperational. Otherwise, it goes into
         * Stopped.
         *
         * It is meaningful only if the #needs_configuration has been specified
         * in the task context definition with (for example):
         \verbatim
         task_context "TaskName" do
           needs_configuration
           ...
         end
         \endverbatim
         */
        bool configureHook();

        /** This hook is called by Orocos when the state machine transitions
         * from Stopped to Running. If it returns false, then the component will
         * stay in Stopped. Otherwise, it goes into Running and updateHook()
         * will be called.
         */
        bool startHook();

        /** This hook is called by Orocos when the component is in the Running
         * state, at each activity step. Here, the activity gives the "ticks"
         * when the hook should be called.
         *
         * The error(), exception() and fatal() calls, when called in this hook,
         * allow to get into the associated RunTimeError, Exception and
         * FatalError states.
         *
         * In the first case, updateHook() is still called, and recover() allows
         * you to go back into the Running state.  In the second case, the
         * errorHook() will be called instead of updateHook(). In Exception, the
         * component is stopped and recover() needs to be called before starting
         * it again. Finally, FatalError cannot be recovered.
         */
        void updateHook();

        /** This hook is called by Orocos when the component is in the
         * RunTimeError state, at each activity step. See the discussion in
         * updateHook() about triggering options.
         *
         * Call recover() to go back in the Runtime state.
         */
        void errorHook();

        /** This hook is called by Orocos when the state machine transitions
         * from Running to Stopped after stop() has been called.
         */
        void stopHook();

        /** This hook is called by Orocos when the state machine transitions
         * from Stopped to PreOperational, requiring the call to configureHook()
         * before calling start() again.
         */
        void cleanupHook();
    };
}

#endif

