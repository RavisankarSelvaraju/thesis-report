#!/bin/bash

source /opt/workspace/env.sh

# Parse named arguments
LOG_DIR_PATH=""
ODOMETRY_PROFILE=""
ODOMETRY=""

while [[ $# -gt 0 ]]; do
    case "$1" in
        --log-path)
            LOG_DIR_PATH="$2"
            shift 2
            ;;
        --profile)
            ODOMETRY_PROFILE="$2"
            shift 2
            ;;
        --odometry)
            ODOMETRY="$2"
            shift 2
            ;;
        *)
            echo "[ERROR] Unknown argument: $1"
            exit 1
            ;;
    esac
done

# Safety checks
if [ -z "$LOG_DIR_PATH" ]; then
    echo "[ERROR] --log-path is required but was not provided."
    exit 1
fi

if [ -z "$ODOMETRY_PROFILE" ]; then
    echo "[ERROR] --profile is required but was not provided."
    exit 1
fi

if [ -z "$ODOMETRY" ]; then
    echo "[ERROR] --odometry is required but was not provided."
    exit 1
fi

# Validate odom type
case "$ODOMETRY" in
    skid_odometry|contact_odometry|contact_velocity_odometry|combined_odometry)
        ;;
    *)
        echo "[ERROR] Unknown odometry type: $ODOMETRY"
        echo "[ERROR] Supported types: skid_odometry, contact_odometry, contact_velocity_odometry, combined_odometry"
        exit 1
        ;;
esac

# Download the required dataset
# check if dataset dir exists
DATASET_DIR="/opt/workspace/datasets/20250207_imu_test"
if [ ! -d "$DATASET_DIR" ]; then
    echo "[INFO] Dataset directory does not exist. Downloading dataset..."
    python3 /opt/workspace/bundles/coyote3_launch/scripts/python/download_anonymous_minio_asset.py 20250207_imu_test.zip
else
    echo "[DEBUG] Dataset directory already exists. Skipping download."
fi

# Resolve VICON data directory from profile number
case "$ODOMETRY_PROFILE" in
    profile_24)
        VICON_DATA_DIR="$DATASET_DIR/20250207-140807.0986"
        ;;
    profile_25)
        VICON_DATA_DIR="$DATASET_DIR/20250207-141526.0279"  
        ;;
    profile_26)
        VICON_DATA_DIR="$DATASET_DIR/20250207-142001.0680"  
        ;;
    thesis_dataset)
        VICON_DATA_DIR="/202605_contact_velocity_odometry/202605_contact_velocity_odometry_mfh/20260515-094155.0700"
        ;;
    *)
        echo "[ERROR] Unknown profile: $ODOMETRY_PROFILE"
        echo "[ERROR] Supported profiles: profile_24, profile_25, profile_26, thesis_dataset"
        exit 1
        ;;
esac

VICON_FILE_NAME="coyote3_vicon_Logger.0.log"
VICON_DATA_PATH="$VICON_DATA_DIR/$VICON_FILE_NAME"

if [ ! -f "$VICON_DATA_PATH" ]; then
    echo "[ERROR] Vicon log file with name: $VICON_FILE_NAME not found in the dataset directory at $VICON_DATA_DIR."
    exit 1
fi

cp "$VICON_DATA_PATH" "$LOG_DIR_PATH/$VICON_FILE_NAME"

# check if the vicon log file was copied successfully
if [ ! -f "$LOG_DIR_PATH/$VICON_FILE_NAME" ]; then
    echo "[ERROR] Failed to copy $VICON_FILE_NAME file to the log directory."
    exit 1
fi
echo "[DEBUG] Copied vicon log file from $VICON_DATA_PATH to $LOG_DIR_PATH"

LOG_NAME=$(basename "$LOG_DIR_PATH")
OUTPUT_LOG_FILE="$LOG_DIR_PATH/${LOG_NAME}_evaluation_results.log"
# Run the evaluation script with the log directory as input
EVAL_CMD=(
    python3 /opt/workspace/coyote3/evaluation_scripts/python/coyote3_evaluation_scripts/vt_eval_odometry.py
    --non-interactive
    --log-dir-path "$LOG_DIR_PATH"
    --odometry "$ODOMETRY"
    --profile "$ODOMETRY_PROFILE"
)

echo "[INFO] Running evaluation script for log directory: $LOG_NAME"

"${EVAL_CMD[@]}" 2>&1 | tee "$OUTPUT_LOG_FILE"
evaluation_exit_code=${PIPESTATUS[0]}

if [ "$evaluation_exit_code" -ne 0 ]; then
    echo "[ERROR] Evaluation script failed with exit code $evaluation_exit_code."
    exit "$evaluation_exit_code"
fi

echo "[INFO] Evaluation log available at $OUTPUT_LOG_FILE"
echo "[INFO] Evaluation script completed successfully."
exit 0

