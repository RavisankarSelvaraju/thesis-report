#include <iostream>
#include <validation_toolset/Validator.hpp>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <base-logging/Logging.hpp>
#include <validation_toolset/Constants.hpp>

using namespace validation_toolset;

const boost::filesystem::path testPath(
    std::string(getenv("AUTOPROJ_CURRENT_ROOT")) +
    "/tools/validation_toolset/examples/confs/coyote3_contact_velocity_odometry_replay.yml");

int main(int argc, char** argv)
{

    /*
    1-Instantiate a validator
    2-Ask the validator to run a test
    3-Ask the validator to run the copy of the tests
    4-Ask the validator to create the db and tables if it does not exists
    5-Ask validator to save the log in the db.
    Points 2-5 will be all put in one method called runAndSaveTest (I/P testPath(yaml description of test))
    */
    Validator v = Validator(logsArchivePath, databasePath);

    boost::optional<Log> currentLog;
    v.runAndSaveTest(testPath, currentLog);
    
    if (!currentLog){
        LOG_WARN("No Log object was assigned. Cannot run evaluation.");
        }
    else{
        LOG_DEBUG("Log for the last run is assigned, Starting Evaluation: ");   
        bool ok = v.evaluateLogs(testPath, *currentLog); // pass the log_id as int not optional
        if (!ok){
            LOG_ERROR("Evaluation of the logs failed.");
        }
        else{
            LOG_DEBUG("Evaluation of the logs completed successfully.");
        }
    }
}

