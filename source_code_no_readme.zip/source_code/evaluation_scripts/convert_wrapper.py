import os
import subprocess
import pocolog2msgpack

def convert_pocolog_to_msgpack(rock_log_file_path, output_file_path, only="", range=""):
    if os.path.exists(output_file_path):
        print(f"File {output_file_path} already exists. Skipping the conversion ...")
    else:
        
        script_path = os.path.join(os.getenv("AUTOPROJ_CURRENT_ROOT"), "coyote3/evaluation_scripts/bash/log_to_msgpack.bash")
        workspace_param = "-w " + os.getenv('AUTOPROJ_CURRENT_ROOT')
        input_param = " -i " + rock_log_file_path
        output_param = " -o " + output_file_path
        cmd = f"{script_path} {workspace_param} {input_param} {output_param}"
        if only != "":
            cmd += f" -s \"{only}\""
        if range != "":
            cmd += f" -r {range}"
        print(f"Running command: {cmd}")
        
        with open("convert_pocolog_to_msgpack.log", "w") as f:
            proc = subprocess.Popen(
                cmd,
                shell=True,
                executable="/bin/bash",
                stdout=f,
                stderr=subprocess.STDOUT
            )
        # proc = subprocess.Popen(cmd, shell=True, executable='/bin/bash', stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # Forward the output in real-time
        # for line in iter(proc.stdout.readline, b''):
        #     print(line.decode(), end='')
        # for line in iter(proc.stderr.readline, b''):
        #     print(line.decode(), end='')
        
        # proc.stdout.close()
        # proc.stderr.close()
        proc.wait()
        
        if proc.returncode != 0:
            print(f"Error: Command exited with code {proc.returncode}")

def convert_msgpack_to_relational(msgpack_dir):
    # For each log file in msgpack_dir, convert it to relational format
    for logfile in os.listdir(msgpack_dir):
        if logfile.endswith('.msgpack'):
            # Check if the corresponding relational file already exists
            if os.path.exists(os.path.join(msgpack_dir, logfile.replace('.msgpack', '.relational'))):
                print(f"File {logfile.replace('.msgpack', '.relational')} already exists. Skipping the conversion ...")
            else:
                logfile_relational = os.path.join(msgpack_dir, logfile.replace('.msgpack', '.relational'))
                pocolog2msgpack.object2relational(os.path.join(msgpack_dir, logfile), logfile_relational)