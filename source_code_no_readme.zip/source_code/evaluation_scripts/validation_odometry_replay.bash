#!/bin/bash

source /opt/workspace/env.sh

if [ -z "$1" ]; then
    echo "Usage: $0 <dataset_id>"
    exit 1
fi

if [ -z "$2" ]; then
    echo "Usage: $0 <dataset_id> [duration_in_seconds]"
    DURATION=60
else
    DURATION="$2"
fi

function stop_cnd(){
    rock-launch /opt/workspace/bundles/coyote3_launch/models/compositions/halt.cnd
    sleep 2
    killall -SIGINT rock-runtime || true
}

DATASET_ID="$1"
BACKGROUND_EXEC=true

echo "Using dataset_id: $DATASET_ID"

TEMPLATE="/opt/workspace/tools/validation_toolset/examples/confs/coyote3_contact_velocity_odometry_replay.template.yml"
OUTPUT="/opt/workspace/tools/validation_toolset/examples/confs/coyote3_contact_velocity_odometry_replay.yml"

sed \
  -e "s/{{dataset_id}}/${DATASET_ID}/g" \
  -e "s/{{duration}}/${DURATION}/g" \
  "$TEMPLATE" > "$OUTPUT"
  
echo "Generated: $OUTPUT"

# Run the odometry playback example in a separate terminal
if [ "$BACKGROUND_EXEC" = "true" ]; then
    echo "Running in background mode, skipping xterm launch..."

    bash -c "
        source /opt/startscripts/validation_launch_and_check.bash
        launch_and_check
    " > /opt/workspace/tools/validation_toolset/logs/validation_outer.log 2>&1 &

    validation_pid=$!
else
    echo "Launching validation_launch_and_check in xterm..."

    setsid xterm -e bash -c "
        source /opt/startscripts/validation_launch_and_check.bash
        launch_and_check
    " &

    validation_pid=$!
fi

echo "Waiting for validation toolset and evaluation to finish..."
wait "$validation_pid"
validation_status=$?

echo "Validation toolset process finished with status: $validation_status"

exit "$validation_status"