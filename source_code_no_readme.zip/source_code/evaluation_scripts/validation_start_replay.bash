#!/bin/bash

##################################################################################### CONSTANTS ###
BUNDLE=coyote3_launch
CND=replay_for_odometry_20250207_imu_test_profile24.cnd
LOGDIR=/opt/workspace
RETRIEVE_CNDS_SCRIPT=/opt/workspace/bundles/coyote3_launch/scripts/python/retrieve_cnds.py
CNDHANDLER_CONFIG=""

##################################################################################### FUNCTIONS ###
# trap ctrl-c and call handle_interupt()
trap 'handle_interupt' INT
function handle_interupt(){
    echo -e "\e[32m*** Trapped CTRL-C => shutting down cnd.\e[0m"
    stop_cnd
    exit 0
}

function stop_cnd(){
    rock-launch /opt/workspace/bundles/$BUNDLE/models/compositions/halt.cnd
    sleep 2
    killall -SIGINT rock-runtime || true
}

function eval_args(){
    cnd_parameter_found=false
    for cnd in "${available_cnds[@]}"; do
        local cnd_name="${cnd%.cnd}"
        if [[ "$1" == "$cnd_name" || "$1" == "$cnd" ]]; then
            CND="$cnd"
            cnd_parameter_found=true
        fi
    done
    if $cnd_parameter_found; then
        echo "Overriding default CND. Now using: $CND"
    else
        echo "Unknown argument passed: $1"
    fi
    if [[ -n "$2" ]]; then
        CNDHANDLER_CONFIG="$2"
        echo "Using CND handler config: $CNDHANDLER_CONFIG"
    else
        echo "No CND handler config provided. Using default."
    fi
}

########################################################################################## MAIN ###
source /opt/workspace/env.sh

# Show available CNDs before processing arguments
mapfile -t available_cnds < <(python $RETRIEVE_CNDS_SCRIPT -t replay -b $BUNDLE)
echo -e "Available replay CNDs:\n**************"
for cnd in "${available_cnds[@]}"; do
    echo "$cnd"
done
echo "******************"


while ! [ -z "$1" ]; do
    eval_args $1 $2
    shift
    if [[ -n "$1" ]]; then
        shift
    fi
done

export __NV_PRIME_RENDER_OFFLOAD=1 
export __GLX_VENDOR_LIBRARY_NAME=nvidia
echo "Restarting omniorb nameserver"
bash /opt/workspace/tools/cnd/orogen/execution/systemd/omniorb_restart.sh 
echo "Selecting bundle $BUNDLE"
rock-bundle-sel $BUNDLE
# export BASE_LOG_LEVEL="debug"
echo "Starting rock_runtime"
echo "Pipe to $LOGDIR"
rock-runtime $CNDHANDLER_CONFIG > $LOGDIR/rock-runtime.log 2>&1 &
tail -n +1 -f "$LOGDIR/rock-runtime.log" \
| sed '/Press <CTRL+C> to exit.../q'
echo "Launching $CND"
rock-launch $CND
