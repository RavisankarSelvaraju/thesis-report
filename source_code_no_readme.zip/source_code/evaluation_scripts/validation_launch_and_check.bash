#!/bin/bash

function launch_and_check(){
    source /opt/workspace/env.sh
    rock-bundle-sel coyote3_launch
    acd tools/validation_toolset
    mkdir -p logs
    cd logs

    ../build/examples/coyote3_contact_velocity_odometry_replay 2> error.log
    status=$?

    if grep -q "Tasks are running waiting for the test to finish" error.log
    then
        echo " **************************************************************** "
        echo "  Odometry playback test passed: the expected message was found"
        echo " **************************************************************** "
    else
        echo "Odometry playback test failed: the expected message was not found"
    fi

    return "$status"
}